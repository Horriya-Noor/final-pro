<?php
/**
 * admin.php — View saved contact submissions
 * IMPORTANT: Protect this file with HTTP Basic Auth or rename/delete after use.
 *
 * Quick HTTP Auth protection example (add to .htaccess):
 *   AuthType Basic
 *   AuthName "Admin"
 *   AuthUserFile /path/to/.htpasswd
 *   Require valid-user
 */

// ── Basic Auth (change credentials!) ───────────────────────
$username = 'admin';
$password = '123';  

if (!isset($_SERVER['PHP_AUTH_USER']) ||
    $_SERVER['PHP_AUTH_USER'] !== $username ||
    $_SERVER['PHP_AUTH_PW']   !== $password) {
    header('WWW-Authenticate: Basic realm="Portfolio Admin"');
    header('HTTP/1.0 401 Unauthorized');
    echo 'Unauthorized';
    exit;
}

$storageFile = __DIR__ . '/contacts.json';
$contacts    = [];

if (file_exists($storageFile)) {
    $raw      = file_get_contents($storageFile);
    $contacts = json_decode($raw, true) ?: [];
}

// Sort newest first
$contacts = array_reverse($contacts);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Contact Submissions — Admin</title>
<style>
  :root {
    --bg: #0a0a0a; --bg2: #111; --bg3: #1a1a1a;
    --text: #f0ece3; --muted: #888; --accent: #c8a96e;
    --border: rgba(255,255,255,0.08);
  }
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { background: var(--bg); color: var(--text); font-family: 'Segoe UI', system-ui, sans-serif; padding: 2rem; }
  h1 { font-size: 1.8rem; color: var(--accent); margin-bottom: 0.4rem; }
  .meta { color: var(--muted); font-size: 0.85rem; margin-bottom: 2rem; }
  .empty { color: var(--muted); font-style: italic; margin-top: 3rem; text-align: center; }
  .card {
    background: var(--bg2); border: 1px solid var(--border);
    border-radius: 12px; padding: 1.5rem; margin-bottom: 1rem;
    transition: border-color 0.2s;
  }
  .card:hover { border-color: rgba(200,169,110,0.3); }
  .card-header { display: flex; justify-content: space-between; align-items: flex-start; flex-wrap: wrap; gap: 0.5rem; margin-bottom: 1rem; }
  .card-name { font-size: 1.1rem; font-weight: 700; }
  .card-email { color: var(--accent); font-size: 0.9rem; }
  .card-meta { color: var(--muted); font-size: 0.78rem; text-align: right; }
  .badge {
    display: inline-block; background: rgba(200,169,110,0.15);
    border: 1px solid rgba(200,169,110,0.3);
    color: var(--accent); font-size: 0.72rem; padding: 0.2rem 0.6rem;
    border-radius: 100px; margin-left: 0.5rem;
  }
  .card-subject { font-weight: 600; margin-bottom: 0.5rem; }
  .card-message { color: var(--muted); line-height: 1.7; font-size: 0.93rem; white-space: pre-wrap; }
  .divider { border: none; border-top: 1px solid var(--border); margin: 1rem 0; }
  .label { font-size: 0.72rem; color: var(--muted); text-transform: uppercase; letter-spacing: 0.1em; }
</style>
</head>
<body>

<h1>📬 Contact Submissions</h1>
<p class="meta"><?= count($contacts) ?> message<?= count($contacts) !== 1 ? 's' : '' ?> received</p>

<?php if (empty($contacts)): ?>
  <p class="empty">No contact submissions yet.</p>
<?php else: ?>
  <?php foreach ($contacts as $c): ?>
    <div class="card">
      <div class="card-header">
        <div>
          <div class="card-name">
            <?= htmlspecialchars($c['name']) ?>
            <?php if (!empty($c['budget'])): ?>
              <span class="badge"><?= htmlspecialchars($c['budget']) ?></span>
            <?php endif; ?>
          </div>
          <div class="card-email"><?= htmlspecialchars($c['email']) ?></div>
        </div>
        <div class="card-meta">
          <?= htmlspecialchars($c['timestamp']) ?><br>
          <span style="font-size:0.7rem"><?= htmlspecialchars($c['ip']) ?></span>
        </div>
      </div>
      <hr class="divider">
      <p class="label">Subject</p>
      <p class="card-subject"><?= htmlspecialchars($c['subject']) ?></p>
      <hr class="divider">
      <p class="label">Message</p>
      <p class="card-message"><?= htmlspecialchars($c['message']) ?></p>
    </div>
  <?php endforeach; ?>
<?php endif; ?>

</body>
</html>
