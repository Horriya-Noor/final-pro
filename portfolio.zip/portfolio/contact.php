<?php
/**
 * contact.php — Portfolio Contact Form Handler
 * Saves contact submissions to a JSON file (no DB required)
 * and optionally sends an email notification.
 */

// ─── CORS & Headers ─────────────────────────────────────────
header('Content-Type: text/plain; charset=UTF-8');
header('X-Content-Type-Options: nosniff');

// Only accept POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo 'Method not allowed';
    exit;
}

// ─── Configuration ──────────────────────────────────────────
define('STORAGE_FILE', __DIR__ . '/contacts.json');
define('NOTIFY_EMAIL', 'hello@alexmercer.dev');   // ← Change to your email
define('SEND_EMAIL',   false);                     // ← Set true to enable email

// ─── Rate limiting (simple IP-based) ────────────────────────
$rateFile  = sys_get_temp_dir() . '/portfolio_rate_' . md5($_SERVER['REMOTE_ADDR'] ?? 'unknown');
$rateLimit = 3;       // max submissions
$rateWindow = 3600;   // per hour (seconds)

if (file_exists($rateFile)) {
    $rateData = json_decode(file_get_contents($rateFile), true);
    if (time() - $rateData['window_start'] < $rateWindow) {
        if ($rateData['count'] >= $rateLimit) {
            http_response_code(429);
            echo 'rate_limit';
            exit;
        }
        $rateData['count']++;
    } else {
        $rateData = ['count' => 1, 'window_start' => time()];
    }
} else {
    $rateData = ['count' => 1, 'window_start' => time()];
}
file_put_contents($rateFile, json_encode($rateData), LOCK_EX);

// ─── Sanitize & Validate ─────────────────────────────────────
function clean(string $value, int $maxLen = 500): string {
    return htmlspecialchars(substr(trim($value), 0, $maxLen), ENT_QUOTES, 'UTF-8');
}

$name    = clean($_POST['name']    ?? '');
$email   = filter_var(trim($_POST['email'] ?? ''), FILTER_SANITIZE_EMAIL);
$subject = clean($_POST['subject'] ?? '');
$budget  = clean($_POST['budget']  ?? '', 50);
$message = clean($_POST['message'] ?? '', 2000);

$errors = [];

if (strlen($name) < 2)             $errors[] = 'Name is too short.';
if (strlen($name) > 100)           $errors[] = 'Name is too long.';
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Invalid email address.';
if (strlen($subject) < 2)          $errors[] = 'Subject is too short.';
if (strlen($message) < 10)         $errors[] = 'Message is too short.';

// Honeypot check (add a hidden field named "website" to the form to catch bots)
if (!empty($_POST['website'])) {
    http_response_code(200);
    echo 'success'; // Silently succeed for bots
    exit;
}

if (!empty($errors)) {
    http_response_code(422);
    echo implode(' ', $errors);
    exit;
}

// ─── Build Contact Record ────────────────────────────────────
$contact = [
    'id'         => uniqid('msg_', true),
    'timestamp'  => date('Y-m-d H:i:s'),
    'ip'         => $_SERVER['REMOTE_ADDR'] ?? 'unknown',
    'name'       => $name,
    'email'      => $email,
    'subject'    => $subject,
    'budget'     => $budget,
    'message'    => $message,
    'user_agent' => substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 200),
];

// ─── Save to JSON Storage ────────────────────────────────────
$contacts = [];

if (file_exists(STORAGE_FILE)) {
    $raw = file_get_contents(STORAGE_FILE);
    $contacts = json_decode($raw, true);
    if (!is_array($contacts)) {
        $contacts = [];
    }
}

$contacts[] = $contact;

$saved = file_put_contents(
    STORAGE_FILE,
    json_encode($contacts, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE),
    LOCK_EX
);

if ($saved === false) {
    http_response_code(500);
    echo 'Storage error. Please email me directly.';
    exit;
}

// ─── Optional Email Notification ─────────────────────────────
if (SEND_EMAIL) {
    $mailTo      = NOTIFY_EMAIL;
    $mailSubject = "New Portfolio Contact: {$subject}";
    $mailBody    = implode("\n", [
        "You received a new portfolio contact submission.",
        "",
        "Name:    {$name}",
        "Email:   {$email}",
        "Subject: {$subject}",
        "Budget:  {$budget}",
        "Date:    {$contact['timestamp']}",
        "",
        "Message:",
        "--------",
        $message,
        "",
        "---",
        "Portfolio Contact System"
    ]);
    $mailHeaders = implode("\r\n", [
        "From: Portfolio <noreply@alexmercer.dev>",
        "Reply-To: {$name} <{$email}>",
        "X-Mailer: PHP/" . PHP_VERSION,
        "Content-Type: text/plain; charset=UTF-8"
    ]);
    mail($mailTo, $mailSubject, $mailBody, $mailHeaders);
}

// ─── Success ─────────────────────────────────────────────────
http_response_code(200);
echo 'success';
