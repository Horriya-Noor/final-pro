# Vibe Player · Music Web App

Vibe Player is a fully interactive, browser-based music application that combines streaming, local file playback, visualizations, and a unique vertical dial interface. It offers a modern, immersive experience with real-time audio analysis, lyrics sync, a queue system, and mood-based theming.

![Vibe Player Screenshot](https://via.placeholder.com/800x400?text=Vibe+Player+Preview)

## ✨ Features

### 🎵 Core Music Features
- **Search & Stream** – Find songs via the iTunes API and play 30-second previews
- **Local File Support** – Load entire folders of audio files (MP3, WAV, etc.)
- **Playback Controls** – Play/Pause, Next/Previous, Seek, Volume, Speed (0.5×–2×)
- **Queue System** – Build a custom playlist by adding tracks from search results
- **Repeat & Shuffle** – Cycle repeat modes (off/all/one) and toggle shuffle
- **Favorites** – ❤ Like songs to save them to a dedicated "Liked" list
- **History** – Automatically tracks your 20 most recently played songs

### 🎨 Visual & Audio Experience
- **Live Wave Visualization** – Bars animate in real-time based on frequency analysis
- **Spinning CD Art** – Vinyl-style disc rotates during playback with artwork
- **Mood Lighting** – Choose from 6 moods to change the entire color scheme
- **EQ Controls** – Adjust Bass and Treble with real-time audio filtering
- **Lyrics Sync** – Fetches and highlights lyrics in sync with playback (via Lyrics.ovh)

### 🎤 Recording & Voice
- **Voice Recording** – Record audio directly from your microphone and download as WAV
- **Voice Search** – Speak to search for songs hands-free (Web Speech API)

### ⚡ Unique Vertical Dial
- **Quick Actions** – A circular dial provides one-tap access to:
  - AI Chat Assistant
  - Queue Viewer
  - Folder Loader
  - Mood Selector
  - Shuffle Toggle
  - Recorder
  - Sleep Timer

### 💬 AI Chat Assistant
- Ask about features, mood, speed, lyrics, shortcuts, and more
- Get contextual help based on the current state of the player

### ⌨️ Keyboard Shortcuts
| Key | Action |
|-----|--------|
| `Space` | Play/Pause |
| `←` / `→` | Seek -5s / +5s |
| `↑` / `↓` | Volume Up / Down |
| `L` | Like / Unlike current track |
| `N` / `P` | Next / Previous track |
| `Esc` | Close dial / popup |

### 💾 Persistence
- Your history, favorites, volume, and mood are saved in `localStorage` across sessions

---

## 🚀 Getting Started

### 1. Clone or Download
```bash
github = clone https://github.com/Horriya-Noor/final-pro/vibe-player
cd vibe-player
```

### 2. Open in Browser
Simply open `index.html` in your browser. No build tools or dependencies are required.

### 3. Optional: Use a Local Server
For the best experience (especially for audio analysis), serve the file locally:

```bash
# Using Python 3
python -m http.server 8000

# Using Node.js (http-server)
npx serve
```

Then open `http://localhost:8000`

---

## 🧭 How to Use

### Search & Play
1. Type an artist, song, or genre in the search bar.
2. Click Search (or press Enter).
3. Click any result to play the preview. The track will be added to the queue.

### Load Local Files
- Click the **📁 Folder** button in the dial (or use the popup) and select a folder containing audio files.
- Local files appear in your history and can be played like any other track.

### Manage Queue
- In search results, click **+ Queue** to add a track to the end of your current playlist.
- View your queue by tapping the **📋 Queue** button in the dial. You can remove tracks from the queue there.

### Like a Song
- Tap the **♡** heart button on the now‑playing card to save the current track to your Liked list.
- Switch between **History** and **Liked** tabs in the History section.

### Use the Vertical Dial
1. Tap the **⚡** button in the bottom‑right corner.
2. The dial expands into a fan of seven action buttons.
3. Tap any button to trigger its function. The dial closes automatically.

### Set a Sleep Timer
- Open the dial and select **⏰ Sleep**.
- Choose 15, 30, or 60 minutes. Playback will pause automatically when the timer ends.

### Ask the AI Assistant
- Open the dial and select **🤖 AI** to open the chat panel.
- Ask questions like "What mood is active?" or "How do I use the loop feature?"

### Voice Search
- Click the **🎤** microphone button in the search bar.
- Speak your search query clearly. The player will automatically search for it.

### Recording
- Press the **🎙️** Record button (either in the controls or the dial) to start recording from your microphone.
- Press it again to stop recording. The file will be downloaded as a `.wav` file.

---

## 🛠 Technical Notes

- **Audio Processing** – Uses the Web Audio API for real‑time frequency analysis and EQ filtering.
- **Data Persistence** – `localStorage` stores your history, favorites, volume, and mood.
- **External APIs** – iTunes Search API for song metadata and previews. Lyrics.ovh for lyrics.
- **CORS** – All external requests are made directly from the browser.

---

## 📁 Project Structure

```
vibe-player/
├── index.html          # Single-file application (HTML + CSS + JS)
└── README.md           # This file
```

---

## 🧪 Browser Compatibility

| Browser | Support |
|---------|---------|
| Chrome  | ✅ Full  |
| Firefox | ✅ Full  |
| Edge    | ✅ Full  |
| Safari  | ⚠️ Most features (some limitations with Web Audio & Speech Recognition) |

---

## 🤝 Contributing

Contributions are welcome! If you'd like to improve Vibe Player:

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

---

## 📄 License

MIT License – free to use, modify, and distribute.

---

## 🙏 Credits

- Built with vanilla JavaScript, HTML5, and CSS3
- Powered by the [iTunes Search API](https://affiliate.itunes.apple.com/resources/documentation/itunes-store-web-service-search-api/)
- Lyrics from [Lyrics.ovh](https://lyrics.ovh/)
- Icons and emojis used for visual clarity

---

## 📬 Contact

Have questions, ideas, or feedback? Open an issue or reach out via GitHub.

---

**Enjoy your Vibe! 🎧**