# Interactive ERD & Database Design Tool

A modern, web-based Entity-Relationship Diagram (ERD) modeler built with **React**, **Tailwind CSS**, and **Lucide Icons**. Design database schemas, model entity relationships, generate data dictionaries, and export production-ready diagrams seamlessly with an intuitive canvas interface.

---

## ✨ Features

- 🎨 **Visual ERD Canvas**: Drag-and-drop support for entities, attributes, relationships, text labels, and subclass inheritance blocks.
- 🔗 **Smart Relationship Connectors**: Connect nodes easily with preset relationship cardinalities:
  - **One-to-One (1:1)**
  - **One-to-Many (1:N)**
  - **Many-to-Many (N:M)**
  - **Inheritance (IS-A)**
  - **Weak / Dashed Links**
  - **Plain Connectors**
- 🔑 **Attribute Modifiers**: Full support for Primary Keys (`PK`), Foreign Keys (`FK`), Multivalued Attributes (`M`), and Derived Attributes (`D`).
- 🪄 **Auto-Align & Beautify**: Automatically layout and structure your diagram nodes cleanly with a single click.
- 🌓 **Dark & Light Mode**: Seamless dark and light theme switching.
- 📊 **Data Dictionary Export**: Instantly export your entity-attribute schema as a structured CSV Data Dictionary (`.csv`).
- 📁 **Import & Export Options**:
  - **JSON Backup**: Save and load full diagram state files (`.json`).
  - **High-Res PNG**: Export clean raster images of your design (`.png`).
  - **Print / PDF**: Direct browser printing and vector PDF export.
- 💾 **Auto-Persistence**: Automatically saves canvas state to local storage.

---

## 🚀 Getting Started

### Prerequisites

Ensure you have **Node.js** (v16.0 or higher) and **npm** / **yarn** / **pnpm** installed on your machine.

### Installation

1. **Clone the repository** or copy the source code into your React project:
   ```bash
   git clone https://github.com/your-username/erd-diagram-tool.git
   cd erd-diagram-tool
   ```

2. **Install dependencies**:
   ```bash
   npm install react react-dom lucide-react
   ```
   *Note: Ensure `tailwindcss` is configured in your project.*

3. **Run the development server**:
   ```bash
   npm run dev
   # or
   npm start
   ```

---

## 🛠️ Usage Guide

### 1. Adding & Editing Nodes
- **Entities**: Select the Entity icon from the left toolbar, then click anywhere on the canvas. Double-click the placed entity to open the editor and manage fields, data types, primary/foreign keys, and accent colors.
- **Attributes**: Standalone attributes can be created and attached using connector lines.
- **Relationships**: Diamond-shaped relationship blocks can be created and named to connect entities (e.g., *Enrolls In*, *Belongs To*).

### 2. Drawing Connectors
1. Select the **Connector Line** tool (`Spline` icon) from the left sidebar.
2. Click on the **source node**.
3. Click on the **target node** to complete the connection.
4. Double-click any line to adjust cardinality (1:1, 1:N, N:M) or add descriptive labels.

### 3. Canvas Controls
- **Pan**: Click and drag on the empty background or use middle-mouse drag.
- **Zoom**: Use the mouse wheel or the Zoom In / Zoom Out controls in the left toolbar.
- **Fit to Screen**: Click the maximize button to frame all nodes on screen.

### 4. Auto-Layout
Click **Auto-Align & Beautify** in the header to hierarchically reorganize your entities, inheritance trees, and connected attributes automatically.

---

## 📋 Data Dictionary CSV Output Format

When exporting a Data Dictionary, the app compiles all entity attributes into a standard format:

| Entity | Attribute | DataType | PrimaryKey | ForeignKey | Multivalued | Derived |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| Student | student_id | INT | true | false | false | false |
| Student | full_name | VARCHAR | false | false | false | false |
| Course | course_id | INT | true | false | false | false |

---

## 📦 Tech Stack

- **Framework**: React 18+
- **Styling**: Tailwind CSS
- **Icons**: [Lucide React](https://lucide.dev/)
- **Storage**: Browser local storage / custom storage wrapper

---

## 📄 License

This project is open source and available under the [MIT License](LICENSE).
