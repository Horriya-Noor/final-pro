import React, { useState, useRef, useEffect, useCallback } from "react";
import {
  MousePointer2, Table2, Layers, Circle, Diamond, Type, Spline,
  Sun, Moon, Wand2, Upload, Download, Check, Loader2, Plus, Trash2,
  X, ChevronDown, FileJson, Printer, FileText, ZoomIn, ZoomOut,
  Maximize2, Key, Link2, PenLine,
} from "lucide-react";

/* ---------------------------------------------------------------------- */
/*  Constants & helpers                                                    */
/* ---------------------------------------------------------------------- */

const uid = () => Math.random().toString(36).slice(2, 10);

const EDGE_TYPES = {
  "one-one": { label: "One-to-One", left: "1", right: "1", dashed: false, marker: null },
  "one-many": { label: "One-to-Many", left: "1", right: "N", dashed: false, marker: null },
  "many-many": { label: "Many-to-Many", left: "N", right: "M", dashed: false, marker: null },
  inheritance: { label: "Inheritance (IS-A)", left: "", right: "", dashed: false, marker: "triangle" },
  weak: { label: "Weak / Dashed", left: "", right: "", dashed: true, marker: null },
  plain: { label: "Plain Connector", left: "", right: "", dashed: false, marker: null },
};

const DATA_TYPES = ["INT", "VARCHAR", "TEXT", "DATE", "DATETIME", "BOOLEAN", "FLOAT", "UUID", "DECIMAL"];

const PALETTE = ["#6366f1", "#0ea5e9", "#10b981", "#f59e0b", "#ef4444", "#a855f7", "#14b8a6", "#64748b"];

const ROW_H = 26;
const HEADER_H = 36;

function nodeWidth(n) {
  if (n.type === "entity" || n.type === "subclass") return n.width || 210;
  if (n.type === "attribute") return 116;
  if (n.type === "relationship") return 140;
  if (n.type === "text") return Math.max(90, (n.text || "").length * 8.5);
  return 120;
}
function nodeHeight(n) {
  if (n.type === "entity" || n.type === "subclass") return HEADER_H + (n.attributes?.length || 0) * ROW_H + 12;
  if (n.type === "attribute") return 58;
  if (n.type === "relationship") return 88;
  if (n.type === "text") return 30;
  return 60;
}
function centerOf(n) {
  return { x: n.x + nodeWidth(n) / 2, y: n.y + nodeHeight(n) / 2 };
}
function borderPoint(cx, cy, w, h, tx, ty) {
  const dx = tx - cx, dy = ty - cy;
  if (dx === 0 && dy === 0) return { x: cx, y: cy };
  const sx = dx !== 0 ? w / 2 / Math.abs(dx) : Infinity;
  const sy = dy !== 0 ? h / 2 / Math.abs(dy) : Infinity;
  const s = Math.min(sx, sy);
  return { x: cx + dx * s, y: cy + dy * s };
}

function makeEntity(x, y, isSubclass) {
  return {
    id: uid(),
    type: isSubclass ? "subclass" : "entity",
    x, y, width: 210,
    name: isSubclass ? "SubClass" : "Entity",
    color: PALETTE[Math.floor(Math.random() * PALETTE.length)],
    border: "solid",
    attributes: [{ id: uid(), name: "id", dataType: "INT", pk: true, fk: false, multivalued: false, derived: false }],
  };
}
function makeAttribute(x, y) {
  return { id: uid(), type: "attribute", x, y, name: "attribute", pk: false, fk: false, multivalued: false, derived: false };
}
function makeRelationship(x, y) {
  return { id: uid(), type: "relationship", x, y, name: "Relationship" };
}
function makeText(x, y) {
  return { id: uid(), type: "text", x, y, text: "Note", fontSize: 15 };
}

const STARTER = {
  fileName: "Untitled ERD",
  nodes: [
    { ...makeEntity(120, 120, false), name: "Student", attributes: [
      { id: uid(), name: "student_id", dataType: "INT", pk: true, fk: false, multivalued: false, derived: false },
      { id: uid(), name: "full_name", dataType: "VARCHAR", pk: false, fk: false, multivalued: false, derived: false },
      { id: uid(), name: "email", dataType: "VARCHAR", pk: false, fk: false, multivalued: false, derived: false },
    ] },
    { ...makeEntity(520, 120, false), name: "Course", color: "#0ea5e9", attributes: [
      { id: uid(), name: "course_id", dataType: "INT", pk: true, fk: false, multivalued: false, derived: false },
      { id: uid(), name: "title", dataType: "VARCHAR", pk: false, fk: false, multivalued: false, derived: false },
    ] },
    { ...makeRelationship(340, 300), name: "Enrolls In" },
  ],
  edges: [],
};
STARTER.edges = [
  { id: uid(), source: STARTER.nodes[0].id, target: STARTER.nodes[2].id, type: "one-many", label: "" },
  { id: uid(), source: STARTER.nodes[2].id, target: STARTER.nodes[1].id, type: "many-many", label: "" },
];

/* ---------------------------------------------------------------------- */
/*  Small UI atoms                                                         */
/* ---------------------------------------------------------------------- */

function IconBtn({ icon: Icon, label, active, onClick, dark, disabled }) {
  return (
    <button
      title={label}
      disabled={disabled}
      onClick={onClick}
      className={`group relative flex items-center justify-center w-11 h-11 rounded-xl transition-all
        ${active
          ? "bg-indigo-600 text-white shadow-lg shadow-indigo-600/30"
          : dark
          ? "text-slate-300 hover:bg-slate-800"
          : "text-slate-600 hover:bg-slate-100"}
        ${disabled ? "opacity-30 cursor-not-allowed" : ""}`}
    >
      <Icon size={19} strokeWidth={2} />
      <span className={`pointer-events-none absolute left-14 z-50 whitespace-nowrap rounded-md px-2 py-1 text-xs font-medium
        opacity-0 group-hover:opacity-100 transition-opacity
        ${dark ? "bg-slate-800 text-slate-100" : "bg-slate-900 text-white"}`}>
        {label}
      </span>
    </button>
  );
}

function Chip({ children, color }) {
  return (
    <span className="px-1.5 py-[1px] rounded text-[9px] font-bold tracking-wide text-white" style={{ background: color }}>
      {children}
    </span>
  );
}

/* ---------------------------------------------------------------------- */
/*  Main App                                                                */
/* ---------------------------------------------------------------------- */

export default function ERDApp() {
  const [dark, setDark] = useState(true);
  const [fileName, setFileName] = useState(STARTER.fileName);
  const [nodes, setNodes] = useState(STARTER.nodes);
  const [edges, setEdges] = useState(STARTER.edges);
  const [tool, setTool] = useState("select");
  const [pan, setPan] = useState({ x: 80, y: 40 });
  const [zoom, setZoom] = useState(1);
  const [selected, setSelected] = useState(null); // {kind:'node'|'edge', id}
  const [pendingConnector, setPendingConnector] = useState(null);
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });
  const [editingNode, setEditingNode] = useState(null);
  const [editingEdge, setEditingEdge] = useState(null);
  const [draggingId, setDraggingId] = useState(null);
  const [saveStatus, setSaveStatus] = useState("saved"); // idle | saving | saved
  const [exportOpen, setExportOpen] = useState(false);
  const [loaded, setLoaded] = useState(false);

  const containerRef = useRef(null);
  const svgRef = useRef(null);
  const saveTimer = useRef(null);
  const fileInputRef = useRef(null);

  /* ------------------------- persistence (window.storage) -------------- */

  useEffect(() => {
    (async () => {
      try {
        if (window.storage) {
          const res = await window.storage.get("erd_project_v1");
          if (res && res.value) {
            const data = JSON.parse(res.value);
            if (data.nodes && data.edges) {
              setNodes(data.nodes);
              setEdges(data.edges);
              setFileName(data.fileName || "Untitled ERD");
            }
          }
        }
      } catch (e) {
        /* no saved project yet — keep starter diagram */
      } finally {
        setLoaded(true);
      }
    })();
  }, []);

  useEffect(() => {
    if (!loaded) return;
    setSaveStatus("saving");
    if (saveTimer.current) clearTimeout(saveTimer.current);
    saveTimer.current = setTimeout(async () => {
      try {
        if (window.storage) {
          await window.storage.set("erd_project_v1", JSON.stringify({ fileName, nodes, edges }));
        }
        setSaveStatus("saved");
      } catch (e) {
        setSaveStatus("saved");
      }
    }, 700);
    return () => clearTimeout(saveTimer.current);
  }, [nodes, edges, fileName, loaded]);

  /* ------------------------------ helpers -------------------------------- */

  const screenToCanvas = useCallback((clientX, clientY) => {
    const rect = containerRef.current.getBoundingClientRect();
    return { x: (clientX - rect.left - pan.x) / zoom, y: (clientY - rect.top - pan.y) / zoom };
  }, [pan, zoom]);

  const updateNode = (id, patch) => setNodes((prev) => prev.map((n) => (n.id === id ? { ...n, ...patch } : n)));
  const deleteNode = (id) => {
    setNodes((prev) => prev.filter((n) => n.id !== id));
    setEdges((prev) => prev.filter((e) => e.source !== id && e.target !== id));
    setSelected(null);
    setEditingNode(null);
  };
  const updateEdge = (id, patch) => setEdges((prev) => prev.map((e) => (e.id === id ? { ...e, ...patch } : e)));
  const deleteEdge = (id) => {
    setEdges((prev) => prev.filter((e) => e.id !== id));
    setSelected(null);
    setEditingEdge(null);
  };

  /* --------------------------- creation on canvas ------------------------ */

  const CREATORS = {
    entity: (p) => makeEntity(p.x - 100, p.y - 30, false),
    subclass: (p) => makeEntity(p.x - 100, p.y - 30, true),
    attribute: (p) => makeAttribute(p.x - 55, p.y - 28),
    relationship: (p) => makeRelationship(p.x - 70, p.y - 44),
    text: (p) => makeText(p.x - 40, p.y - 14),
  };

  const handleBackgroundMouseDown = (e) => {
    if (e.button === 1 || (e.button === 0 && tool === "select")) {
      // pan
      const start = { x: e.clientX, y: e.clientY, panX: pan.x, panY: pan.y };
      const move = (ev) => {
        setPan({ x: start.panX + (ev.clientX - start.x), y: start.panY + (ev.clientY - start.y) });
      };
      const up = () => {
        window.removeEventListener("mousemove", move);
        window.removeEventListener("mouseup", up);
      };
      window.addEventListener("mousemove", move);
      window.addEventListener("mouseup", up);
      setSelected(null);
      return;
    }
    if (CREATORS[tool]) {
      const p = screenToCanvas(e.clientX, e.clientY);
      const node = CREATORS[tool](p);
      setNodes((prev) => [...prev, node]);
      setSelected({ kind: "node", id: node.id });
      setTool("select");
    } else if (tool === "connector") {
      setPendingConnector(null);
    }
  };

  const handleSvgMouseMove = (e) => {
    if (pendingConnector) {
      setMousePos(screenToCanvas(e.clientX, e.clientY));
    }
  };

  const handleNodeMouseDown = (e, node) => {
    e.stopPropagation();
    if (tool === "connector") {
      if (!pendingConnector) {
        setPendingConnector(node.id);
      } else if (pendingConnector !== node.id) {
        const newEdge = { id: uid(), source: pendingConnector, target: node.id, type: "one-many", label: "" };
        setEdges((prev) => [...prev, newEdge]);
        setPendingConnector(null);
        setTool("select");
      } else {
        setPendingConnector(null);
      }
      return;
    }
    setSelected({ kind: "node", id: node.id });
    const start = { x: e.clientX, y: e.clientY, ox: node.x, oy: node.y };
    setDraggingId(node.id);
    const move = (ev) => {
      const dx = (ev.clientX - start.x) / zoom;
      const dy = (ev.clientY - start.y) / zoom;
      updateNode(node.id, { x: start.ox + dx, y: start.oy + dy });
    };
    const up = () => {
      setDraggingId(null);
      window.removeEventListener("mousemove", move);
      window.removeEventListener("mouseup", up);
    };
    window.addEventListener("mousemove", move);
    window.addEventListener("mouseup", up);
  };

  const handleWheel = (e) => {
    e.preventDefault();
    const rect = containerRef.current.getBoundingClientRect();
    const mx = e.clientX - rect.left, my = e.clientY - rect.top;
    const factor = e.deltaY < 0 ? 1.08 : 0.93;
    const newZoom = Math.min(2.5, Math.max(0.25, zoom * factor));
    const cxBefore = (mx - pan.x) / zoom, cyBefore = (my - pan.y) / zoom;
    setPan({ x: mx - cxBefore * newZoom, y: my - cyBefore * newZoom });
    setZoom(newZoom);
  };

  const zoomBy = (factor) => {
    const rect = containerRef.current.getBoundingClientRect();
    const mx = rect.width / 2, my = rect.height / 2;
    const newZoom = Math.min(2.5, Math.max(0.25, zoom * factor));
    const cxBefore = (mx - pan.x) / zoom, cyBefore = (my - pan.y) / zoom;
    setPan({ x: mx - cxBefore * newZoom, y: my - cyBefore * newZoom });
    setZoom(newZoom);
  };

  const fitToScreen = () => {
    if (nodes.length === 0) { setPan({ x: 80, y: 40 }); setZoom(1); return; }
    const xs = nodes.map((n) => n.x), ys = nodes.map((n) => n.y);
    const xe = nodes.map((n) => n.x + nodeWidth(n)), ye = nodes.map((n) => n.y + nodeHeight(n));
    const minX = Math.min(...xs) - 60, minY = Math.min(...ys) - 60;
    const maxX = Math.max(...xe) + 60, maxY = Math.max(...ye) + 60;
    const rect = containerRef.current.getBoundingClientRect();
    const scale = Math.min(rect.width / (maxX - minX), rect.height / (maxY - minY), 1.4);
    setZoom(scale);
    setPan({ x: -minX * scale, y: -minY * scale });
  };

  /* ------------------------------ keyboard -------------------------------- */

  useEffect(() => {
    const onKey = (e) => {
      if (e.key === "Escape") { setPendingConnector(null); setTool("select"); setEditingNode(null); setEditingEdge(null); }
      if ((e.key === "Delete" || e.key === "Backspace") && selected && !editingNode && !editingEdge) {
        const tag = document.activeElement?.tagName;
        if (tag === "INPUT" || tag === "TEXTAREA") return;
        if (selected.kind === "node") deleteNode(selected.id);
        if (selected.kind === "edge") deleteEdge(selected.id);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [selected, editingNode, editingEdge]);

  /* ------------------------------ auto align ------------------------------ */

  const autoAlign = () => {
    const structural = nodes.filter((n) => n.type === "entity" || n.type === "subclass" || n.type === "relationship");
    const parentOf = {};
    edges.forEach((e) => { if (e.type === "inheritance") parentOf[e.source] = e.target; });
    const levelCache = {};
    const levelOf = (id, seen = new Set()) => {
      if (levelCache[id] !== undefined) return levelCache[id];
      if (seen.has(id)) return 0;
      seen.add(id);
      const p = parentOf[id];
      const lvl = p ? levelOf(p, seen) + 1 : 0;
      levelCache[id] = lvl;
      return lvl;
    };
    structural.forEach((n) => levelOf(n.id));
    const levels = {};
    structural.forEach((n) => { const l = levelCache[n.id] || 0; (levels[l] = levels[l] || []).push(n); });
    const newPos = {};
    Object.keys(levels).map(Number).sort((a, b) => a - b).forEach((l) => {
      const arr = levels[l].sort((a, b) => (a.name || "").localeCompare(b.name || ""));
      let x = 100;
      arr.forEach((n) => {
        newPos[n.id] = { x, y: 90 + l * 210 };
        x += nodeWidth(n) + 70;
      });
    });
    nodes.forEach((n) => {
      if (n.type === "attribute") {
        const edge = edges.find((e) => e.source === n.id || e.target === n.id);
        const otherId = edge && (edge.source === n.id ? edge.target : edge.source);
        const parentPos = newPos[otherId];
        if (parentPos) newPos[n.id] = { x: parentPos.x + Math.random() * 60 - 30, y: parentPos.y - 90 };
      }
    });
    setNodes((prev) => prev.map((n) => (newPos[n.id] ? { ...n, x: newPos[n.id].x, y: newPos[n.id].y } : n)));
    setTimeout(fitToScreen, 60);
  };

  /* ------------------------------ import / export -------------------------- */

  const download = (blob, name) => {
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = name; a.click();
    URL.revokeObjectURL(url);
  };

  const exportJSON = () => {
    download(new Blob([JSON.stringify({ fileName, nodes, edges }, null, 2)], { type: "application/json" }), `${fileName}.json`);
    setExportOpen(false);
  };

  const importJSON = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const data = JSON.parse(reader.result);
        if (data.nodes && data.edges) {
          setNodes(data.nodes); setEdges(data.edges); setFileName(data.fileName || file.name.replace(/\.json$/, ""));
        }
      } catch (err) { alert("Couldn't read that file — is it a valid diagram JSON export?"); }
    };
    reader.readAsText(file);
    e.target.value = "";
  };

  const exportPNG = () => {
    const svg = svgRef.current;
    if (!svg) return;
    const xs = nodes.map((n) => n.x), ys = nodes.map((n) => n.y);
    const xe = nodes.map((n) => n.x + nodeWidth(n)), ye = nodes.map((n) => n.y + nodeHeight(n));
    const minX = Math.min(...xs, 0) - 40, minY = Math.min(...ys, 0) - 40;
    const maxX = Math.max(...xe, 400) + 40, maxY = Math.max(...ye, 300) + 40;
    const w = maxX - minX, h = maxY - minY;
    const clone = svg.cloneNode(true);
    clone.setAttribute("width", w);
    clone.setAttribute("height", h);
    clone.setAttribute("viewBox", `${minX} ${minY} ${w} ${h}`);
    const innerG = clone.querySelector("g[data-canvas-root]");
    if (innerG) innerG.removeAttribute("style");
    const bg = document.createElementNS("http://www.w3.org/2000/svg", "rect");
    bg.setAttribute("x", minX); bg.setAttribute("y", minY); bg.setAttribute("width", w); bg.setAttribute("height", h);
    bg.setAttribute("fill", dark ? "#0f172a" : "#ffffff");
    clone.insertBefore(bg, clone.firstChild);
    const svgStr = new XMLSerializer().serializeToString(clone);
    const svgBlob = new Blob([svgStr], { type: "image/svg+xml;charset=utf-8" });
    const url = URL.createObjectURL(svgBlob);
    const img = new Image();
    img.onload = () => {
      const scale = 2;
      const canvas = document.createElement("canvas");
      canvas.width = w * scale; canvas.height = h * scale;
      const ctx = canvas.getContext("2d");
      ctx.scale(scale, scale);
      ctx.drawImage(img, 0, 0);
      canvas.toBlob((blob) => download(blob, `${fileName}.png`), "image/png");
      URL.revokeObjectURL(url);
    };
    img.src = url;
    setExportOpen(false);
  };

  const exportPrint = () => {
    setExportOpen(false);
    setTimeout(() => window.print(), 100);
  };

  const exportDataDictionary = () => {
    let csv = "Entity,Attribute,DataType,PrimaryKey,ForeignKey,Multivalued,Derived\n";
    nodes.filter((n) => n.type === "entity" || n.type === "subclass").forEach((n) => {
      (n.attributes || []).forEach((a) => {
        csv += `${n.name},${a.name},${a.dataType},${a.pk},${a.fk},${a.multivalued},${a.derived}\n`;
      });
    });
    download(new Blob([csv], { type: "text/csv" }), `${fileName}-data-dictionary.csv`);
    setExportOpen(false);
  };

  /* ------------------------------ rendering -------------------------------- */

  const bg = dark ? "bg-slate-950" : "bg-slate-50";
  const panelBg = dark ? "bg-slate-900 border-slate-800" : "bg-white border-slate-200";
  const text = dark ? "text-slate-100" : "text-slate-900";
  const subtext = dark ? "text-slate-400" : "text-slate-500";

  const TOOLS = [
    { id: "select", icon: MousePointer2, label: "Select / Move" },
    { id: "entity", icon: Table2, label: "Entity / Class Box" },
    { id: "subclass", icon: Layers, label: "Subclass / Derived Entity" },
    { id: "attribute", icon: Circle, label: "Attribute" },
    { id: "relationship", icon: Diamond, label: "Relationship" },
    { id: "text", icon: Type, label: "Text Label" },
    { id: "connector", icon: Spline, label: "Connector Line" },
  ];

  return (
    <div className={`h-[100dvh] w-full flex flex-col overflow-hidden font-sans ${bg} ${text} select-none`}>
      {/* -------------------------- HEADER -------------------------- */}
      <header className={`print:hidden flex items-center gap-3 h-16 px-4 border-b shrink-0 ${panelBg}`}>
        <div className="flex items-center gap-2 pr-3 border-r border-slate-700/20">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-indigo-500 to-violet-600 flex items-center justify-center shadow-md shadow-indigo-500/30">
            <Layers size={16} className="text-white" />
          </div>
          <input
            value={fileName}
            onChange={(e) => setFileName(e.target.value)}
            className={`bg-transparent font-semibold text-sm w-40 outline-none border-b border-transparent focus:border-indigo-500 transition-colors`}
          />
        </div>

        <div className={`flex items-center gap-1.5 text-xs ${subtext}`}>
          {saveStatus === "saving" ? (
            <><Loader2 size={13} className="animate-spin" /> Saving…</>
          ) : (
            <><Check size={13} className="text-emerald-500" /> Saved</>
          )}
        </div>

        <div className="flex-1" />

        <button
          onClick={autoAlign}
          className="flex items-center gap-1.5 text-xs font-medium px-3 py-2 rounded-lg bg-gradient-to-r from-indigo-600 to-violet-600 text-white hover:brightness-110 transition-all shadow-sm"
        >
          <Wand2 size={14} /> Auto-Align & Beautify
        </button>

        <button
          onClick={() => fileInputRef.current?.click()}
          className={`flex items-center gap-1.5 text-xs font-medium px-3 py-2 rounded-lg border ${dark ? "border-slate-700 hover:bg-slate-800" : "border-slate-300 hover:bg-slate-100"}`}
        >
          <Upload size={14} /> Upload File
        </button>
        <input ref={fileInputRef} type="file" accept=".json" className="hidden" onChange={importJSON} />

        <div className="relative">
          <button
            onClick={() => setExportOpen((v) => !v)}
            className={`flex items-center gap-1.5 text-xs font-medium px-3 py-2 rounded-lg border ${dark ? "border-slate-700 hover:bg-slate-800" : "border-slate-300 hover:bg-slate-100"}`}
          >
            <Download size={14} /> Export <ChevronDown size={12} />
          </button>
          {exportOpen && (
            <div className={`absolute right-0 top-11 w-56 rounded-xl border shadow-xl overflow-hidden z-50 ${panelBg}`}>
              <button onClick={exportPrint} className={`w-full flex items-center gap-2 px-3 py-2.5 text-xs hover:bg-indigo-500/10`}>
                <Printer size={14} /> Print / Save as PDF
              </button>
              <button onClick={exportDataDictionary} className={`w-full flex items-center gap-2 px-3 py-2.5 text-xs hover:bg-indigo-500/10`}>
                <FileText size={14} /> Data Dictionary (.csv)
              </button>
              <button onClick={exportPNG} className={`w-full flex items-center gap-2 px-3 py-2.5 text-xs hover:bg-indigo-500/10`}>
                <FileText size={14} /> Diagram Image (.png)
              </button>
              <button onClick={exportJSON} className={`w-full flex items-center gap-2 px-3 py-2.5 text-xs hover:bg-indigo-500/10`}>
                <FileJson size={14} /> Full Backup (.json)
              </button>
            </div>
          )}
        </div>

        {/* dark / light toggle switch */}
        <button
          onClick={() => setDark((v) => !v)}
          aria-label="Toggle dark and light mode"
          className={`relative w-14 h-8 rounded-full flex items-center px-1 transition-colors shrink-0 ${dark ? "bg-indigo-600" : "bg-amber-400"}`}
        >
          <span className={`absolute w-6 h-6 rounded-full bg-white shadow-md flex items-center justify-center transition-transform duration-300 ${dark ? "translate-x-6" : "translate-x-0"}`}>
            {dark ? <Moon size={13} className="text-indigo-600" /> : <Sun size={13} className="text-amber-500" />}
          </span>
        </button>
      </header>

      <div className="flex flex-1 overflow-hidden">
        {/* -------------------------- LEFT TOOLBAR -------------------------- */}
        <aside className={`print:hidden flex flex-col items-center gap-2 w-[68px] py-4 border-r shrink-0 ${panelBg}`}>
          {TOOLS.map((t) => (
            <IconBtn key={t.id} icon={t.icon} label={t.label} active={tool === t.id} dark={dark} onClick={() => { setTool(t.id); setPendingConnector(null); }} />
          ))}
          <div className={`w-8 h-px my-2 ${dark ? "bg-slate-800" : "bg-slate-200"}`} />
          <IconBtn icon={ZoomIn} label="Zoom In" dark={dark} onClick={() => zoomBy(1.2)} />
          <IconBtn icon={ZoomOut} label="Zoom Out" dark={dark} onClick={() => zoomBy(0.8)} />
          <IconBtn icon={Maximize2} label="Fit to Screen" dark={dark} onClick={fitToScreen} />
        </aside>

        {/* -------------------------- CANVAS -------------------------- */}
        <div
          ref={containerRef}
          onWheel={handleWheel}
          onMouseDown={handleBackgroundMouseDown}
          className={`relative flex-1 overflow-hidden ${tool === "select" ? "cursor-grab active:cursor-grabbing" : "cursor-crosshair"}`}
          style={{
            backgroundImage: `radial-gradient(${dark ? "#334155" : "#cbd5e1"} 1px, transparent 1px)`,
            backgroundSize: `${24 * zoom}px ${24 * zoom}px`,
            backgroundPosition: `${pan.x}px ${pan.y}px`,
          }}
        >
          <svg ref={svgRef} className="absolute inset-0 w-full h-full print:hidden-off" onMouseMove={handleSvgMouseMove}>
            <defs>
              <marker id="arrow-tri" markerWidth="14" markerHeight="12" refX="12" refY="6" orient="auto">
                <path d="M0,0 L12,6 L0,12 Z" fill={dark ? "#0f172a" : "#f8fafc"} stroke={dark ? "#94a3b8" : "#475569"} strokeWidth="1" />
              </marker>
            </defs>
            <g data-canvas-root style={{ transform: `translate(${pan.x}px, ${pan.y}px) scale(${zoom})`, transformOrigin: "0 0" }}>
              {/* ---------------- edges ---------------- */}
              {edges.map((edge) => {
                const s = nodes.find((n) => n.id === edge.source);
                const t = nodes.find((n) => n.id === edge.target);
                if (!s || !t) return null;
                const cs = centerOf(s), ct = centerOf(t);
                const p1 = borderPoint(cs.x, cs.y, nodeWidth(s), nodeHeight(s), ct.x, ct.y);
                const p2 = borderPoint(ct.x, ct.y, nodeWidth(t), nodeHeight(t), cs.x, cs.y);
                const cfg = EDGE_TYPES[edge.type] || EDGE_TYPES.plain;
                const isSel = selected?.kind === "edge" && selected.id === edge.id;
                const mx = (p1.x + p2.x) / 2, my = (p1.y + p2.y) / 2;
                const lx1 = p1.x + (p2.x - p1.x) * 0.18, ly1 = p1.y + (p2.y - p1.y) * 0.18;
                const lx2 = p1.x + (p2.x - p1.x) * 0.82, ly2 = p1.y + (p2.y - p1.y) * 0.82;
                const stroke = isSel ? "#6366f1" : dark ? "#64748b" : "#94a3b8";
                return (
                  <g key={edge.id}>
                    <line x1={p1.x} y1={p1.y} x2={p2.x} y2={p2.y}
                      stroke={stroke} strokeWidth={isSel ? 2.5 : 1.8}
                      strokeDasharray={cfg.dashed ? "6 4" : undefined}
                      markerEnd={cfg.marker === "triangle" ? "url(#arrow-tri)" : undefined} />
                    <line x1={p1.x} y1={p1.y} x2={p2.x} y2={p2.y} stroke="transparent" strokeWidth={16}
                      onClick={(e) => { e.stopPropagation(); setSelected({ kind: "edge", id: edge.id }); }}
                      onDoubleClick={(e) => { e.stopPropagation(); setEditingEdge(edge.id); }}
                      style={{ cursor: "pointer" }} />
                    {cfg.left && (
                      <text x={lx1} y={ly1 - 6} fontSize="11" fontWeight="700" fill={dark ? "#cbd5e1" : "#334155"} textAnchor="middle">{cfg.left}</text>
                    )}
                    {cfg.right && (
                      <text x={lx2} y={ly2 - 6} fontSize="11" fontWeight="700" fill={dark ? "#cbd5e1" : "#334155"} textAnchor="middle">{cfg.right}</text>
                    )}
                    {edge.label && (
                      <text x={mx} y={my - 8} fontSize="11" fontStyle="italic" fill={dark ? "#a5b4fc" : "#4f46e5"} textAnchor="middle">{edge.label}</text>
                    )}
                  </g>
                );
              })}

              {/* ---------------- pending connector preview ---------------- */}
              {pendingConnector && (() => {
                const s = nodes.find((n) => n.id === pendingConnector);
                if (!s) return null;
                const cs = centerOf(s);
                return <line x1={cs.x} y1={cs.y} x2={mousePos.x} y2={mousePos.y} stroke="#6366f1" strokeWidth={2} strokeDasharray="5 4" />;
              })()}

              {/* ---------------- nodes ---------------- */}
              {nodes.map((n) => (
                <NodeShape
                  key={n.id}
                  node={n}
                  dark={dark}
                  selected={selected?.kind === "node" && selected.id === n.id}
                  dragging={draggingId === n.id}
                  pending={pendingConnector === n.id}
                  onMouseDown={(e) => handleNodeMouseDown(e, n)}
                  onDoubleClick={(e) => { e.stopPropagation(); if (tool === "select") setEditingNode(n.id); }}
                />
              ))}
            </g>
          </svg>

          {/* zoom readout */}
          <div className={`print:hidden absolute bottom-4 left-4 text-[11px] font-medium px-2.5 py-1.5 rounded-lg border ${panelBg} ${subtext}`}>
            {Math.round(zoom * 100)}%
          </div>
          {tool === "connector" && (
            <div className={`print:hidden absolute top-4 left-1/2 -translate-x-1/2 text-xs font-medium px-3 py-1.5 rounded-lg border ${panelBg} ${subtext}`}>
              {pendingConnector ? "Click a target node to connect… (Esc to cancel)" : "Click a source node to start a connector"}
            </div>
          )}
        </div>
      </div>

      {editingNode && (
        <NodeEditor
          node={nodes.find((n) => n.id === editingNode)}
          dark={dark}
          onClose={() => setEditingNode(null)}
          onSave={(patch) => updateNode(editingNode, patch)}
          onDelete={() => deleteNode(editingNode)}
        />
      )}
      {editingEdge && (
        <EdgeEditor
          edge={edges.find((e) => e.id === editingEdge)}
          dark={dark}
          onClose={() => setEditingEdge(null)}
          onSave={(patch) => updateEdge(editingEdge, patch)}
          onDelete={() => deleteEdge(editingEdge)}
        />
      )}
    </div>
  );
}

/* ---------------------------------------------------------------------- */
/*  Node shape                                                              */
/* ---------------------------------------------------------------------- */

function NodeShape({ node, dark, selected, dragging, pending, onMouseDown, onDoubleClick }) {
  const w = nodeWidth(node), h = nodeHeight(node);
  const style = {
    transform: `translate(${node.x}px, ${node.y}px)`,
    transition: dragging ? "none" : "transform 0.55s cubic-bezier(.4,0,.2,1)",
    cursor: dragging ? "grabbing" : "pointer",
  };
  const ringColor = pending ? "#f59e0b" : "#6366f1";
  const selRing = (selected || pending) && (
    <rect x={-4} y={-4} width={w + 8} height={h + 8} rx={12} fill="none" stroke={ringColor} strokeWidth={2} strokeDasharray={pending ? "4 3" : undefined} />
  );

  if (node.type === "entity" || node.type === "subclass") {
    const bodyFill = dark ? "#1e293b" : "#ffffff";
    const stroke = dark ? "#334155" : "#e2e8f0";
    return (
      <g style={style} onMouseDown={onMouseDown} onDoubleClick={onDoubleClick}>
        {selRing}
        <rect width={w} height={h} rx={10} fill={bodyFill} stroke={stroke} strokeWidth={1.5}
          strokeDasharray={node.type === "subclass" ? "1 0" : undefined} />
        {node.type === "subclass" && <rect x={3} y={3} width={w - 6} height={h - 6} rx={7} fill="none" stroke={node.color} strokeWidth={1} strokeDasharray="3 3" opacity={0.6} />}
        <rect width={w} height={HEADER_H} rx={10} fill={node.color} />
        <rect y={HEADER_H - 10} width={w} height={10} fill={node.color} />
        <text x={12} y={23} fontSize="13" fontWeight="700" fill="#ffffff">{node.name}</text>
        {node.type === "subclass" && <text x={w - 10} y={23} fontSize="9" fontWeight="700" fill="#ffffffcc" textAnchor="end">IS-A</text>}
        {(node.attributes || []).map((a, i) => {
          const y = HEADER_H + i * ROW_H;
          return (
            <g key={a.id}>
              <rect y={y} width={w} height={ROW_H} fill={i % 2 === 0 ? "transparent" : dark ? "#0f172a55" : "#f8fafc"} />
              <text x={12} y={y + 17} fontSize="11.5" fontWeight={a.pk ? 700 : 400}
                textDecoration={a.pk ? "underline" : "none"}
                fill={dark ? "#e2e8f0" : "#1e293b"}>{a.name}</text>
              <text x={w - 12} y={y + 17} fontSize="9.5" fill={dark ? "#94a3b8" : "#64748b"} textAnchor="end">{a.dataType}</text>
              <g transform={`translate(${w - (a.dataType.length * 5.5) - 16},${y + 6})`}>
                {a.pk && <g transform="translate(-38,0)"><rect width={16} height={13} rx={3} fill="#f59e0b" /><text x={8} y={10} fontSize="8" fontWeight="700" fill="#fff" textAnchor="middle">PK</text></g>}
                {a.fk && <g transform="translate(-19,0)"><rect width={16} height={13} rx={3} fill="#0ea5e9" /><text x={8} y={10} fontSize="8" fontWeight="700" fill="#fff" textAnchor="middle">FK</text></g>}
              </g>
            </g>
          );
        })}
      </g>
    );
  }

  if (node.type === "attribute") {
    const cx = w / 2, cy = h / 2;
    return (
      <g style={style} onMouseDown={onMouseDown} onDoubleClick={onDoubleClick}>
        {selRing}
        {node.multivalued && <ellipse cx={cx} cy={cy} rx={w / 2} ry={h / 2} fill="none" stroke={dark ? "#475569" : "#94a3b8"} strokeWidth={1.5} />}
        <ellipse cx={cx} cy={cy} rx={w / 2 - (node.multivalued ? 4 : 0)} ry={h / 2 - (node.multivalued ? 4 : 0)}
          fill={dark ? "#1e293b" : "#ffffff"} stroke={dark ? "#64748b" : "#94a3b8"} strokeWidth={1.5}
          strokeDasharray={node.derived ? "4 3" : undefined} />
        <text x={cx} y={cy + 4} fontSize="11" textAnchor="middle" textDecoration={node.pk ? "underline" : "none"} fontWeight={node.pk ? 700 : 500} fill={dark ? "#e2e8f0" : "#1e293b"}>
          {node.name}{node.fk ? " (fk)" : ""}
        </text>
      </g>
    );
  }

  if (node.type === "relationship") {
    const pts = `${w / 2},0 ${w},${h / 2} ${w / 2},${h} 0,${h / 2}`;
    return (
      <g style={style} onMouseDown={onMouseDown} onDoubleClick={onDoubleClick}>
        {selRing}
        <polygon points={pts} fill={dark ? "#312e81" : "#eef2ff"} stroke="#6366f1" strokeWidth={1.5} />
        <text x={w / 2} y={h / 2 + 4} fontSize="11" fontWeight="600" textAnchor="middle" fill={dark ? "#e0e7ff" : "#4338ca"}>{node.name}</text>
      </g>
    );
  }

  // text label
  return (
    <g style={style} onMouseDown={onMouseDown} onDoubleClick={onDoubleClick}>
      {selRing}
      <text x={2} y={20} fontSize={node.fontSize || 15} fontWeight="500" fill={dark ? "#f1f5f9" : "#0f172a"}>{node.text}</text>
    </g>
  );
}

/* ---------------------------------------------------------------------- */
/*  Node editor modal                                                       */
/* ---------------------------------------------------------------------- */

function Modal({ dark, onClose, children, wide }) {
  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/50 backdrop-blur-sm p-4" onMouseDown={onClose}>
      <div
        onMouseDown={(e) => e.stopPropagation()}
        className={`${wide ? "w-[560px]" : "w-[420px]"} max-h-[85vh] overflow-y-auto rounded-2xl border shadow-2xl ${dark ? "bg-slate-900 border-slate-700 text-slate-100" : "bg-white border-slate-200 text-slate-900"}`}
      >
        {children}
      </div>
    </div>
  );
}

function fieldCls(dark) {
  return `w-full text-sm rounded-lg border px-3 py-2 outline-none focus:ring-2 focus:ring-indigo-500 ${dark ? "bg-slate-800 border-slate-700" : "bg-slate-50 border-slate-200"}`;
}

function NodeEditor({ node, dark, onClose, onSave, onDelete }) {
  const [draft, setDraft] = useState(node);
  useEffect(() => setDraft(node), [node]);
  if (!draft) return null;

  const commit = (patch) => { const next = { ...draft, ...patch }; setDraft(next); onSave(patch); };
  const isBox = draft.type === "entity" || draft.type === "subclass";

  const addAttr = () => {
    const attrs = [...(draft.attributes || []), { id: uid(), name: "new_field", dataType: "VARCHAR", pk: false, fk: false, multivalued: false, derived: false }];
    commit({ attributes: attrs });
  };
  const updAttr = (id, patch) => commit({ attributes: draft.attributes.map((a) => (a.id === id ? { ...a, ...patch } : a)) });
  const delAttr = (id) => commit({ attributes: draft.attributes.filter((a) => a.id !== id) });

  return (
    <Modal dark={dark} onClose={onClose} wide={isBox}>
      <div className={`flex items-center justify-between px-5 py-4 border-b ${dark ? "border-slate-800" : "border-slate-200"}`}>
        <h3 className="font-semibold text-sm">
          {isBox ? "Edit Entity" : draft.type === "attribute" ? "Edit Attribute" : draft.type === "relationship" ? "Edit Relationship" : "Edit Text Label"}
        </h3>
        <button onClick={onClose} className="opacity-60 hover:opacity-100"><X size={16} /></button>
      </div>

      <div className="p-5 space-y-4">
        {draft.type === "text" ? (
          <>
            <label className="text-xs font-medium opacity-70">Text</label>
            <textarea rows={3} className={fieldCls(dark)} value={draft.text} onChange={(e) => commit({ text: e.target.value })} />
            <label className="text-xs font-medium opacity-70">Font size</label>
            <input type="range" min="10" max="36" value={draft.fontSize || 15} onChange={(e) => commit({ fontSize: Number(e.target.value) })} className="w-full" />
          </>
        ) : (
          <>
            <div>
              <label className="text-xs font-medium opacity-70">Name</label>
              <input className={fieldCls(dark)} value={draft.name} onChange={(e) => commit({ name: e.target.value })} />
            </div>

            {isBox && (
              <>
                <div className="flex gap-4">
                  <div className="flex-1">
                    <label className="text-xs font-medium opacity-70 block mb-1.5">Color</label>
                    <div className="flex gap-1.5 flex-wrap">
                      {PALETTE.map((c) => (
                        <button key={c} onClick={() => commit({ color: c })}
                          className={`w-6 h-6 rounded-full ring-offset-2 ${draft.color === c ? "ring-2 ring-indigo-500" : ""}`}
                          style={{ background: c, boxShadow: draft.color === c ? undefined : "0 0 0 1px rgba(0,0,0,.1)" }} />
                      ))}
                    </div>
                  </div>
                  <div className="flex-1">
                    <label className="text-xs font-medium opacity-70 block mb-1.5">Border style</label>
                    <select className={fieldCls(dark)} value={draft.border} onChange={(e) => commit({ border: e.target.value })}>
                      <option value="solid">Solid</option>
                      <option value="double">Double</option>
                    </select>
                  </div>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <label className="text-xs font-medium opacity-70">Attributes</label>
                    <button onClick={addAttr} className="flex items-center gap-1 text-xs font-medium text-indigo-500 hover:text-indigo-400">
                      <Plus size={13} /> Add field
                    </button>
                  </div>
                  <div className="space-y-1.5">
                    {(draft.attributes || []).map((a) => (
                      <div key={a.id} className={`flex items-center gap-1.5 p-1.5 rounded-lg border ${dark ? "border-slate-800 bg-slate-800/40" : "border-slate-200 bg-slate-50"}`}>
                        <input value={a.name} onChange={(e) => updAttr(a.id, { name: e.target.value })}
                          className={`flex-1 text-xs bg-transparent outline-none px-1.5 py-1 rounded ${dark ? "focus:bg-slate-800" : "focus:bg-white"}`} />
                        <select value={a.dataType} onChange={(e) => updAttr(a.id, { dataType: e.target.value })}
                          className={`text-xs rounded px-1 py-1 outline-none ${dark ? "bg-slate-900" : "bg-white"}`}>
                          {DATA_TYPES.map((t) => <option key={t}>{t}</option>)}
                        </select>
                        {[["pk", "PK", "#f59e0b"], ["fk", "FK", "#0ea5e9"], ["multivalued", "M", "#a855f7"], ["derived", "D", "#10b981"]].map(([key, label, color]) => (
                          <button key={key} title={key} onClick={() => updAttr(a.id, { [key]: !a[key] })}
                            className="w-6 h-6 rounded text-[9px] font-bold shrink-0"
                            style={{ background: a[key] ? color : "transparent", color: a[key] ? "#fff" : dark ? "#64748b" : "#94a3b8", border: `1px solid ${a[key] ? color : dark ? "#334155" : "#cbd5e1"}` }}>
                            {label}
                          </button>
                        ))}
                        <button onClick={() => delAttr(a.id)} className="text-red-400 hover:text-red-500 shrink-0"><X size={13} /></button>
                      </div>
                    ))}
                  </div>
                </div>
              </>
            )}

            {draft.type === "attribute" && (
              <div className="grid grid-cols-2 gap-2">
                {[["pk", "Primary Key"], ["fk", "Foreign Key"], ["multivalued", "Multivalued"], ["derived", "Derived"]].map(([key, label]) => (
                  <label key={key} className={`flex items-center gap-2 text-xs rounded-lg border px-3 py-2 cursor-pointer ${dark ? "border-slate-700" : "border-slate-200"}`}>
                    <input type="checkbox" checked={!!draft[key]} onChange={(e) => commit({ [key]: e.target.checked })} />
                    {label}
                  </label>
                ))}
              </div>
            )}
          </>
        )}
      </div>

      <div className={`flex items-center justify-between px-5 py-4 border-t ${dark ? "border-slate-800" : "border-slate-200"}`}>
        <button onClick={onDelete} className="flex items-center gap-1.5 text-xs font-medium text-red-500 hover:text-red-400">
          <Trash2 size={14} /> Delete
        </button>
        <button onClick={onClose} className="text-xs font-medium px-4 py-2 rounded-lg bg-indigo-600 text-white hover:bg-indigo-500">Done</button>
      </div>
    </Modal>
  );
}

/* ---------------------------------------------------------------------- */
/*  Edge editor modal                                                       */
/* ---------------------------------------------------------------------- */

function EdgeEditor({ edge, dark, onClose, onSave, onDelete }) {
  const [draft, setDraft] = useState(edge);
  useEffect(() => setDraft(edge), [edge]);
  if (!draft) return null;
  const commit = (patch) => { const next = { ...draft, ...patch }; setDraft(next); onSave(patch); };

  return (
    <Modal dark={dark} onClose={onClose}>
      <div className={`flex items-center justify-between px-5 py-4 border-b ${dark ? "border-slate-800" : "border-slate-200"}`}>
        <h3 className="font-semibold text-sm flex items-center gap-2"><Link2 size={15} /> Edit Connector</h3>
        <button onClick={onClose} className="opacity-60 hover:opacity-100"><X size={16} /></button>
      </div>
      <div className="p-5 space-y-4">
        <div>
          <label className="text-xs font-medium opacity-70">Relationship type</label>
          <select className={fieldCls(dark)} value={draft.type} onChange={(e) => commit({ type: e.target.value })}>
            {Object.entries(EDGE_TYPES).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
          </select>
        </div>
        <div>
          <label className="text-xs font-medium opacity-70">Label (optional)</label>
          <input className={fieldCls(dark)} value={draft.label || ""} onChange={(e) => commit({ label: e.target.value })} placeholder="e.g. enrolls in" />
        </div>
      </div>
      <div className={`flex items-center justify-between px-5 py-4 border-t ${dark ? "border-slate-800" : "border-slate-200"}`}>
        <button onClick={onDelete} className="flex items-center gap-1.5 text-xs font-medium text-red-500 hover:text-red-400">
          <Trash2 size={14} /> Delete
        </button>
        <button onClick={onClose} className="text-xs font-medium px-4 py-2 rounded-lg bg-indigo-600 text-white hover:bg-indigo-500">Done</button>
      </div>
    </Modal>
  );
}
