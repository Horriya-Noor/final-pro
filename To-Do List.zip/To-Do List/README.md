# Hoor! – Productivity Dashboard with Namaz Tracker

A full‑featured, self‑hosted to‑do list and productivity dashboard that tracks tasks, daily prayers (Namaz), and visualizes your performance with live charts and a real‑time timeline. Built with vanilla HTML, CSS, and JavaScript, served by a lightweight Node.js server.

---

## ✨ Features

- **Secure Login** – Simple demo credentials (Hoor / enter123).
- **Task Management** – Add, edit, delete, and mark tasks as done. Each task stores creation and completion timestamps.
- **Namaz Tracker** – Toggle the five daily prayers (Fajr, Dhuhr, Asr, Maghrib, Isha). Tracks today’s count and calculates your current streak of perfect days.
- **Live Timeline** – Every action (task added, completed, edited, deleted; namaz toggled) is recorded with an exact timestamp (hours, minutes, seconds).
- **Performance Charts** – Four interactive Chart.js charts:
  - Weekly tasks completed (bar chart)
  - Namaz completion for today (doughnut)
  - Monthly trend: tasks done + namaz percentage over the last 12 months (line chart)
  - Task priority breakdown (pie chart)
- **Monthly Calendar View** – Each day is color‑coded based on the total activity (tasks completed + namaz offered). Hover to see the exact score.
- **Motivational Quotes** – Rotating quotes in the banner, updated every 18 seconds.
- **Dark / Light Mode** – Toggle with a single button.
- **Real‑Time Clock** – Live clock in the header.
- **Server Status Indicator** – Shows that the Node.js server is running.
- **Persistent Storage** – All data (tasks, namaz log, timeline) is saved in your browser’s `localStorage`, so nothing is lost on refresh.

---

## 🛠️ Technology Stack

- **Frontend**: HTML5, CSS3 (custom properties for theming), Vanilla JavaScript (ES6)
- **Charts**: [Chart.js](https://www.chartjs.org/) (CDN)
- **Backend**: Node.js (HTTP server – serves static files)
- **Storage**: `localStorage` (no database required)

---

## 🚀 Getting Started

### Prerequisites

- [Node.js](https://nodejs.org/) (v14 or later) installed on your machine.

### Installation

1. **Clone or download** this repository to a folder on your computer.

2. **Navigate** to the project folder in your terminal.

3. **Start the server**:

   ```bash
   node server.js
   ```

   You should see:

   ```
   ✅ TaskFlow is running!
   👉 Open this in your browser: http://localhost:3000
   ```

4. **Open your browser** and go to [http://localhost:3000](http://localhost:3000).

5. **Log in** with the default credentials:

   - **Username**: `Hoor`
   - **Password**: `enter123`

---

## 📁 Project Structure

```
/
├── server.js         # Node.js HTTP server (serves index.html)
├── index.html        # Complete single‑page application (all CSS/JS included)
└── README.md         # This file
```

> **Note**: All frontend code (HTML, CSS, JavaScript) is embedded in `index.html` for simplicity – no additional asset files needed.

---

## 📖 How It Works

### Data Persistence
- All tasks, namaz logs, and timeline events are stored in `localStorage` under the keys `hoor_todos`, `hoor_namaz`, and `hoor_timeline`.
- Data survives page refreshes and browser restarts. To reset, clear your browser’s local storage for this domain.

### Timeline Events
- Every user action that changes state (adding/editing/deleting/completing a task, toggling a prayer) is logged with a unique ID, type, description, icon, and ISO timestamp.
- The timeline displays the most recent 40 events in reverse chronological order (newest first).

### Charts
- **Weekly Tasks**: Calculates how many tasks were completed on each of the last 7 days.
- **Namaz Doughnut**: Shows today’s prayer status (full segments for offered, partial for missed).
- **Monthly Trend**: Compares tasks done per month and namaz completion percentage over the last 12 months.
- **Priority Pie**: Shows the distribution of tasks by priority (High / Mid / Low).

### Monthly Calendar
- Each day’s activity score is computed as:
  `completed tasks on that day + 0.5 * (number of namaz offered that day)`
- The score determines the color intensity (5 levels). The current day is highlighted with a border.

---

## 🧩 Customization

- **Quotes**: Edit the `QUOTES` array in the `<script>` section to add or change motivational messages.
- **User Credentials**: Modify the `USERS` object in the JavaScript to add more login pairs.
- **Namaz Names/Emojis**: Adjust the `NAMAZ_NAMES` and `NAMAZ_EMOJIS` arrays.
- **Theme Colors**: Update the CSS custom properties in `:root` and `.light`.
- **Port Number**: Change the `PORT` variable in `server.js` (default: 3000).

---

## 🤝 Contributing

Contributions are welcome! Feel free to open issues or submit pull requests for improvements, bug fixes, or new features.

---

## 📄 License

This project is open‑source and available under the [MIT License](LICENSE).

---

## 🙏 Acknowledgments

- [Chart.js](https://www.chartjs.org/) for beautiful, responsive charts.
- Font Awesome (via CDN) for icons.
- The open‑source community for endless inspiration.

---

**Happy tracking!**  
Made with ❤️ — Hoor © 2026