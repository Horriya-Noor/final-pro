# 🌌 Horriya Noor · 3D Cosmic Portfolio

A futuristic, interactive personal portfolio built as a single HTML file. It features a dynamic 3D hero scene, a vibrant card-based navigation system, and a fully responsive design with dark mode.

![Portfolio Preview](https://via.placeholder.com/800x400?text=Portfolio+Preview)  
*(Replace with a live screenshot if you have one)*

---

## ✨ Features

- **Immersive 3D Hero** – A rotating torus knot surrounded by a particle galaxy, reacting to mouse movement.
- **AI Voice Assistant** – On page load, a professional voice introduces Horriya. Each card triggers a unique 2–3 sentence voice response (About, Background, Projects, etc.). Built with the Web Speech API.
- **Card‑Based Navigation** – Each card represents a section (About, Projects, Skills, etc.). Click to trigger a 3D rotation + explode animation.
- **Rotary Skill Dial** – An interactive semi‑circle dial with skill logos. Click any logo – the dial smoothly rotates to bring it to the centre, revealing proficiency percentage and a description.
- **Detail Overlays** – Full‑page views with your profile picture, structured content, project mini‑cards, testimonials grid, achievements grid, and the skill dial.
- **Project Modals** – Each project opens in a modal with full description, tech stack tags, and outcome highlights.
- **Dark / Light Mode** – Seamless theme toggle with persistent local storage.
- **Contact Form** – Validates input and simulates a successful submission.
- **Particle Background (2D)** – Subtle drifting particles with connecting lines.
- **Fully Responsive** – Adapts to all screen sizes, from desktop to mobile.
---

## 🚀 Technologies Used

- **HTML5** – Structure  
- **CSS3** – Custom properties, animations, glass‑morphism, responsive grid  
- **JavaScript (ES6)** – Interactivity, particle system, card logic  
- **Three.js** – 3D scene rendering (loaded via CDN)  
- **Font Awesome** – Icons  
- **Google Fonts** – Inter & JetBrains Mono  
- **Voice Synthesis** -	Web Speech API (SpeechSynthesis)

---

## 📁 Project Structure

The entire project is contained in a **single HTML file** with inline CSS and JavaScript. No build tools or external dependencies (except CDN libraries) are required.

```
index.html          # Complete portfolio
README.md           # This file
```

---

## 🛠️ Getting Started

### 1. Clone or Download

```bash
git clone https://github.com/your-username/your-repo.git
cd your-repo
```

### 2. Open the File

Simply open `index.html` in your favourite browser.

- **Recommended**: Chrome, Firefox, or Edge for the best 3D performance.

### 3. Customize (Optional)

- **Profile Name & Initials**:  
  Search for `Horriya Noor` and `HN` in the code and replace with your own.
- **Profile Picture**:  
  Replace the avatar `<div>` with your own image. Look for `profile-pic-large` and `profile-avatar-sm` classes.
- **Card Content**:  
  The `cardData` array in the `<script>` tag holds all the section data. Edit titles, descriptions, and the `content` HTML strings.
- **Colors**:  
  The theme uses a vibrant palette (`#00ffcc`, `#ff00aa`, etc.). Modify the CSS variables `:root` and `dark` sections.

---

## 🧩 How It Works

1. **Hero Section (3D)**  
   - The `#three-container` holds the Three.js scene with a torus knot, rings, and particles.  
   - Mouse movement subtly rotates the knot.

2. **AI Voice Assistant**
   - Uses the `SpeechSynthesis` API.
   - The `speak()` function creates an utterance, selects a female voice if available, and shows a floating indicator.
   - On page load, the intro message is spoken. Each card triggers its own response when opened.

3. **Cards & Explode Animation**
   - Each card has a `data-index` and a click listener.
   - Clicking adds the `exploding` CSS class (3D rotation + scaling), then opens the detail overlay after a delay.

4. **Detail Overlay**
   - Content is injected dynamically from `cardData`.
   - For the Skills card, the rotary dial is rendered. For Projects, Testimonials, and Achievements, their respective grids are populated.
   - The back button resets card visibility and closes the overlay (and cancels any ongoing speech).

5. **Rotary Skill Dial**
   - Skills are positioned along a semicircle using trigonometry.
   - Clicking a skill rotates the inner dial to bring it to the centre (with a smooth cubic‑bezier transition).
   - The selected skill’s icon, name, description, and proficiency bar update instantly.

6. **Project Modals**
   - Clicking a project mini‑card opens a modal with full details, role, outcome, and technology tags.

7. **Dark Mode**
   - Toggle adds/removes the `.dark` class on <html>.
   - CSS variables update globally, and the Three.js scene colours adapt via a `MutationObserver`.
   - The 2D particle canvas also adjusts its colours.

8. **Particle System (2D)**
   - Rendered on a <canvas> behind the main content.
   - Particles drift slowly and connect with semi‑transparent lines when within 150px.


---

## 📦 Dependencies (CDN)

- **Three.js** – `https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js`  
- **Font Awesome** – `https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css`  
- **Google Fonts** – `Inter` & `JetBrains Mono`

---

## 🤝 Contributing

This is a personal portfolio, but if you spot a bug or have a suggestion, feel free to open an issue or submit a pull request.

---

## 📄 License

This project is **MIT Licensed**. You are free to use, modify, and distribute it as you wish. Attribution is appreciated but not required.

---

## 🙌 Acknowledgments

- Three.js community for the amazing 3D library.  
- Font Awesome for the icon set.  
- Google Fonts for the beautiful typography.

---

Made with 💙 and a lot of cosmic energy.  
*– Horriya Noor*