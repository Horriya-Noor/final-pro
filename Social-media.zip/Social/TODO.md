# Social Network Platform - Enhancement TODO

## Phase 1: Backend Enhancements (server.js) ✅
- [x] Add multer dependency for file uploads
- [x] Add rich dummy data (more users, posts with media, notifications, chats)
- [x] Add file upload endpoint `/api/upload`
- [x] Add search endpoint `/api/search`
- [x] Add notification preferences endpoint
- [x] Add online user tracking with WebSocket
- [x] Add WebSocket events: typing indicators, chat rooms, online status
- [x] Add follow/unfollow functionality
- [x] Enhanced notification categories
- [x] Decline friend request endpoint
- [x] Mark messages as read endpoint
- [x] Mark all notifications as read endpoint

## Phase 2: Frontend JavaScript (app.js)
- [x] Real-time chat with dedicated socket events
- [x] Typing indicators
- [x] Online/offline status indicators
- [x] Multimedia display (video, audio embeds)
- [x] File upload handler with drag-drop
- [x] Search functionality (users, posts, hashtags)
- [x] Enhanced notification rendering with categories
- [x] Notification badge counts
- [x] Hashtag click-to-search
- [x] Profile follower/following lists
- [x] Notification preferences UI
- [x] Dynamic data binding for all pages

## Phase 3: CSS Styles (styles.css)
- [x] Upload zone / drag-drop styles
- [x] Video/audio embed styles
- [x] Typing indicator animation
- [x] Online status dot indicator
- [x] Notification badge counter
- [x] Search results dropdown panel
- [x] Modal overlay for media viewer
- [x] Enhanced chat bubble styles with read receipts
- [x] Loading spinner

## Phase 4: HTML Pages
- [x] index.html - Login page with enhanced auth
- [x] app.html - Dashboard with all enhancements
- [x] login.html - Standalone login page
- [x] profile.html - Live profile with follower/following tabs
- [x] explore.html - Live explore with search, hashtags, trending
- [x] notifications.html - Categorized notifications
- [x] messages.html - Real-time chat UI
- [x] settings.html - Notification preferences, privacy toggles
- [x] edit-profile.html - Profile editor with live preview

## Phase 5: Infrastructure
- [x] Create public/uploads/ directory
- [x] Install multer npm package
- [x] Update package.json

## Phase 6: Testing
- [ ] Run the server and verify
- [ ] Verify real-time updates
- [ ] Verify file upload
- [ ] Verify search
- [ ] Verify chat with typing indicators

