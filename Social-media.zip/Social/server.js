const express = require('express');
const http = require('http');
const path = require('path');
const cors = require('cors');
const multer = require('multer');
const { Server } = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: {
    origin: '*'
  }
});

// Multer setup for file uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, path.join(__dirname, 'public', 'uploads'));
  },
  filename: (req, file, cb) => {
    const unique = Date.now() + '-' + Math.round(Math.random() * 1e9);
    const ext = path.extname(file.originalname);
    cb(null, unique + ext);
  }
});
const upload = multer({
  storage,
  limits: { fileSize: 50 * 1024 * 1024 }, // 50MB limit
  fileFilter: (req, file, cb) => {
    const allowed = /jpeg|jpg|png|gif|webp|mp4|webm|ogg|mp3|wav|pdf|doc|docx|txt/;
    const mime = allowed.test(file.mimetype);
    const ext = allowed.test(path.extname(file.originalname).toLowerCase());
    if (mime || ext) return cb(null, true);
    cb(new Error('File type not supported.'));
  }
});

app.use(cors());
app.use(express.json({ limit: '50mb' }));
app.use('/uploads', express.static(path.join(__dirname, 'public', 'uploads')));

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'login.html'));
});

app.get('/app', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'app.html'));
});

app.use(express.static(path.join(__dirname, 'public')));

// ========== RICH DUMMY DATA ==========
const initialState = {
  user: {
    id: 'u1',
    name: 'Ari Chen',
    role: 'Product Designer',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=400&q=80',
    coverPhoto: 'https://images.unsplash.com/photo-1519681393784-d120267933ba?auto=format&fit=crop&w=1200&q=80',
    location: 'Seattle, USA',
    followers: 1284,
    following: 320,
    score: 96,
    headline: 'Crafting meaningful digital communities',
    website: 'https://arichen.design',
    joined: 'March 2022',
    followersList: [],
    followingList: []
  },
  users: [
    {
      id: 'u1',
      name: 'Ari Chen',
      role: 'Product Designer',
      avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=400&q=80',
      coverPhoto: 'https://images.unsplash.com/photo-1519681393784-d120267933ba?auto=format&fit=crop&w=1200&q=80',
      location: 'Seattle, USA',
      headline: 'Crafting meaningful digital communities',
      website: 'https://arichen.design',
      joined: 'March 2022'
    },
    {
      id: 'u2',
      name: 'Mina Patel',
      role: 'Community Builder',
      avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?auto=format&fit=crop&w=300&q=80',
      coverPhoto: 'https://images.unsplash.com/photo-1470071459604-ce3e5c0f48f1?auto=format&fit=crop&w=1200&q=80',
      location: 'Austin, USA',
      headline: 'Building brighter digital circles',
      website: 'https://minapatel.com',
      joined: 'January 2023'
    },
    {
      id: 'u3',
      name: 'Lin Wei',
      role: 'AI Researcher',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
      coverPhoto: 'https://images.unsplash.com/photo-1462331940025-496dfbfc7564?auto=format&fit=crop&w=1200&q=80',
      location: 'San Francisco, USA',
      headline: 'Democratizing AI for creators',
      website: 'https://linwei.dev',
      joined: 'November 2021'
    },
    {
      id: 'u4',
      name: 'Neva Rivera',
      role: 'Visual Storyteller',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80',
      coverPhoto: 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=1200&q=80',
      location: 'Barcelona, Spain',
      headline: 'Capturing moments that matter',
      website: 'https://nevarivera.art',
      joined: 'July 2022'
    },
    {
      id: 'u5',
      name: 'Jules Fontaine',
      role: 'Product Educator',
      avatar: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&w=300&q=80',
      coverPhoto: 'https://images.unsplash.com/photo-1475924156734-496f6cac6ec1?auto=format&fit=crop&w=1200&q=80',
      location: 'Paris, France',
      headline: 'Teaching product thinking globally',
      website: 'https://julesfontaine.io',
      joined: 'September 2021'
    }
  ],
  posts: [
    {
      id: 'p1',
      author: 'Ari Chen',
      userId: 'u1',
      handle: '@ari',
      content: '🚀 Just launched a new community-curated feed with richer storytelling and instant reactions. Check out the new media embeds!',
      likes: 24,
      likedByMe: false,
      likedBy: ['u2', 'u3'],
      comments: [
        { id: 'c1', author: 'Mina Patel', userId: 'u2', text: 'The animations feel premium already. Love the glass effect!', time: '2m ago' },
        { id: 'c2', author: 'Lin Wei', userId: 'u3', text: 'Can we integrate this with the AI moderation stack?', time: '1m ago' }
      ],
      time: '2m ago',
      privacy: 'Public',
      image: 'https://images.unsplash.com/photo-1516321497487-e288fb19713f?auto=format&fit=crop&w=900&q=80',
      mediaType: 'image',
      tags: ['#Design', '#Community', '#Launch']
    },
    {
      id: 'p2',
      author: 'Lin Wei',
      userId: 'u3',
      handle: '@linwei',
      content: 'Sharing a behind-the-scenes look at our new AI-assisted moderation tools. The future of safe online spaces is here.',
      likes: 17,
      likedByMe: true,
      likedBy: ['u1', 'u4'],
      comments: [
        { id: 'c2', author: 'Ari Chen', userId: 'u1', text: 'Love the transparency. When can we test this?', time: '18m ago' }
      ],
      time: '18m ago',
      privacy: 'Friends',
      image: 'https://images.unsplash.com/photo-1677442136019-21780ecad995?auto=format&fit=crop&w=900&q=80',
      mediaType: 'image',
      tags: ['#AI', '#Moderation', '#Tech']
    },
    {
      id: 'p3',
      author: 'Neva Rivera',
      userId: 'u4',
      handle: '@neva',
      content: 'Golden hour in Barcelona. Sometimes you just need to pause and take it all in. 🌅',
      likes: 42,
      likedByMe: false,
      likedBy: ['u1', 'u2', 'u5'],
      comments: [
        { id: 'c3', author: 'Jules Fontaine', userId: 'u5', text: 'Stunning capture! What camera did you use?', time: '45m ago' },
        { id: 'c4', author: 'Mina Patel', userId: 'u2', text: 'I need to visit Barcelona ASAP 😍', time: '30m ago' }
      ],
      time: '1h ago',
      privacy: 'Public',
      image: 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=900&q=80',
      mediaType: 'image',
      tags: ['#Photography', '#Travel', '#GoldenHour']
    },
    {
      id: 'p4',
      author: 'Mina Patel',
      userId: 'u2',
      handle: '@mina',
      content: 'Just hosted our biggest community workshop yet! 200+ creators showed up to talk about building inclusive digital spaces. The energy was incredible!',
      likes: 56,
      likedByMe: false,
      likedBy: ['u1', 'u3', 'u4', 'u5'],
      comments: [
        { id: 'c5', author: 'Ari Chen', userId: 'u1', text: 'It was amazing! So many great ideas shared.', time: '3h ago' }
      ],
      time: '3h ago',
      privacy: 'Public',
      image: 'https://images.unsplash.com/photo-1515187029135-18ee286d815b?auto=format&fit=crop&w=900&q=80',
      mediaType: 'image',
      tags: ['#Community', '#Workshop', '#Inclusion']
    },
    {
      id: 'p5',
      author: 'Jules Fontaine',
      userId: 'u5',
      handle: '@jules',
      content: '📹 New video: "5 Product Design Principles Every Creator Should Know" — check it out and let me know what you think!',
      likes: 31,
      likedByMe: false,
      likedBy: ['u1', 'u4'],
      comments: [],
      time: '5h ago',
      privacy: 'Public',
      image: 'https://images.unsplash.com/photo-1588196749597-9ff075ee6b5b?auto=format&fit=crop&w=900&q=80',
      mediaType: 'video',
      tags: ['#Design', '#Education', '#Video']
    },
    {
      id: 'p6',
      author: 'Ari Chen',
      userId: 'u1',
      handle: '@ari',
      content: 'Excited to announce our newest feature: real-time collaborative boards! Perfect for brainstorming sessions with your community. 🎉\n\nDrop a 🧵 if you want early access!',
      likes: 89,
      likedByMe: true,
      likedBy: ['u2', 'u3', 'u4', 'u5'],
      comments: [
        { id: 'c6', author: 'Lin Wei', userId: 'u3', text: 'This is a game changer! Sign me up 🧵', time: '6h ago' },
        { id: 'c7', author: 'Neva Rivera', userId: 'u4', text: '🧵 Would love to test this with my community!', time: '5h ago' },
        { id: 'c8', author: 'Mina Patel', userId: 'u2', text: 'Amazing work Ari! The team crushed this 💪', time: '4h ago' }
      ],
      time: '6h ago',
      privacy: 'Public',
      image: 'https://images.unsplash.com/photo-1611532736597-de2d4265fba3?auto=format&fit=crop&w=900&q=80',
      mediaType: 'image',
      tags: ['#Launch', '#Collaboration', '#Community']
    },
    {
      id: 'p7',
      author: 'Lin Wei',
      userId: 'u3',
      handle: '@linwei',
      content: 'Mind-blowing AI research paper dropped today. The implications for content creation and moderation are huge. Here\'s my thread breaking it down 🧵',
      likes: 45,
      likedByMe: false,
      likedBy: ['u1', 'u5'],
      comments: [
        { id: 'c9', author: 'Jules Fontaine', userId: 'u5', text: 'Great breakdown! The attention mechanism is fascinating.', time: '8h ago' }
      ],
      time: '8h ago',
      privacy: 'Public',
      image: '',
      mediaType: 'text',
      tags: ['#AI', '#Research', '#Tech']
    },
    {
      id: 'p8',
      author: 'Neva Rivera',
      userId: 'u4',
      handle: '@neva',
      content: '🎵 Sound on for this one! Captured the ambient waves at Costa Brava this morning. Pure therapy.',
      likes: 67,
      likedByMe: false,
      likedBy: ['u1', 'u2', 'u3'],
      comments: [
        { id: 'c10', author: 'Ari Chen', userId: 'u1', text: 'I can feel the calm from here. Beautiful 🎵', time: '10h ago' }
      ],
      time: '10h ago',
      privacy: 'Public',
      image: 'https://images.unsplash.com/photo-1505228395891-9a51e7e86bf6?auto=format&fit=crop&w=900&q=80',
      mediaType: 'audio',
      tags: ['#Nature', '#Soundscapes', '#Travel']
    }
  ],
  requests: [
    { id: 'r1', name: 'Mina Patel', userId: 'u2', avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?auto=format&fit=crop&w=300&q=80', status: 'pending' },
    { id: 'r2', name: 'Lin Wei', userId: 'u3', avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80', status: 'pending' }
  ],
  notifications: [
    { id: 'n1', type: 'friend_request', text: 'Mina Patel wants to connect with you.', user: 'Mina Patel', userId: 'u2', avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?auto=format&fit=crop&w=300&q=80', time: '2m ago', read: false },
    { id: 'n2', type: 'like', text: 'Lin Wei liked your post: "Excited to announce our newest feature"', user: 'Lin Wei', userId: 'u3', avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80', time: '15m ago', read: false },
    { id: 'n3', type: 'comment', text: 'Neva Rivera commented: "🧵 Would love to test this!"', user: 'Neva Rivera', userId: 'u4', avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80', time: '1h ago', read: false },
    { id: 'n4', type: 'system', text: 'Welcome to SocialSphere 2.0 — new features now live!', user: 'System', userId: '', avatar: '', time: '3h ago', read: true },
    { id: 'n5', type: 'friend_accept', text: 'Jules Fontaine accepted your friend request.', user: 'Jules Fontaine', userId: 'u5', avatar: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&w=300&q=80', time: '1d ago', read: true }
  ],
  privacy: {
    posts: 'Friends',
    messages: 'Private',
    profile: 'Public'
  },
  social: {
    friends: [
      { id: 'u2', name: 'Mina Patel', avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?auto=format&fit=crop&w=300&q=80', status: 'online' },
      { id: 'u3', name: 'Lin Wei', avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80', status: 'offline' },
      { id: 'u4', name: 'Neva Rivera', avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80', status: 'online' },
      { id: 'u5', name: 'Jules Fontaine', avatar: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&w=300&q=80', status: 'offline' }
    ],
    favorites: [
      { id: 'u2', name: 'Mina Patel', avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?auto=format&fit=crop&w=300&q=80' },
      { id: 'u3', name: 'Lin Wei', avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80' }
    ],
    blocked: []
  },
  chats: [
    {
      id: 'chat-1',
      participant: 'Mina Patel',
      participantId: 'u2',
      avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?auto=format&fit=crop&w=300&q=80',
      status: 'online',
      messages: [
        { id: 'm1', author: 'Mina Patel', authorId: 'u2', text: 'The new space looks amazing! Love the real-time updates.', time: '09:12', read: true },
        { id: 'm2', author: 'You', authorId: 'u1', text: 'Thanks Mina! The collaborative boards are live too.', time: '09:15', read: true },
        { id: 'm3', author: 'Mina Patel', authorId: 'u2', text: 'I want to set up a workshop session this weekend.', time: '09:16', read: false }
      ]
    },
    {
      id: 'chat-2',
      participant: 'Lin Wei',
      participantId: 'u3',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
      status: 'offline',
      messages: [
        { id: 'm4', author: 'Lin Wei', authorId: 'u3', text: 'I read the paper you shared — mind-blowing stuff!', time: 'Yesterday', read: true },
        { id: 'm5', author: 'You', authorId: 'u1', text: 'Right? The attention mechanism applications are huge.', time: 'Yesterday', read: true }
      ]
    }
  ],
  auth: {
    users: [
      {
        id: 'u1',
        name: 'Ari Chen',
        email: 'ari@example.com',
        password: 'demo123',
        role: 'Product Designer',
        location: 'Seattle, USA',
        avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=400&q=80',
        coverPhoto: 'https://images.unsplash.com/photo-1519681393784-d120267933ba?auto=format&fit=crop&w=1200&q=80',
        headline: 'Crafting meaningful digital communities',
        website: 'https://arichen.design'
      }
    ],
    sessions: []
  },
  trending: [
    { tag: '#Design', count: 245 },
    { tag: '#AI', count: 189 },
    { tag: '#Community', count: 156 },
    { tag: '#Launch', count: 98 },
    { tag: '#Tech', count: 87 },
    { tag: '#Photography', count: 76 },
    { tag: '#Travel', count: 65 },
    { tag: '#Education', count: 54 }
  ],
  notificationPreferences: {
    likes: true,
    comments: true,
    friend_requests: true,
    friend_accepts: true,
    mentions: true,
    system: true,
    messages: true
  }
};

// Track online users
const onlineUsers = new Map(); // socketId -> userId

let state = JSON.parse(JSON.stringify(initialState));
let serverInstance = null;

// Helper: get user's followers/following lists
function buildFollowersLists() {
  state.user.followersList = state.users.filter(u => u.id !== 'u1' && u.id !== 'u1').map(u => ({
    id: u.id, name: u.name, avatar: u.avatar, role: u.role
  }));
  state.user.followingList = state.user.followersList.slice(0, 3);
}
buildFollowersLists();

function broadcastState() {
  io.emit('state:update', state);
}

function createNotification(type, text, user = '', userId = '', avatar = '') {
  state.notifications.unshift({
    id: `n${Date.now()}`,
    type,
    text,
    user,
    userId,
    avatar,
    time: 'Just now',
    read: false
  });
  // Broadcast notification to all connected clients
  io.emit('notification:new', state.notifications[0]);
}

function getCurrentUser() {
  return state.user;
}

function getMediaType(filename) {
  const ext = path.extname(filename).toLowerCase();
  if (['.jpg', '.jpeg', '.png', '.gif', '.webp'].includes(ext)) return 'image';
  if (['.mp4', '.webm', '.ogg'].includes(ext)) return 'video';
  if (['.mp3', '.wav'].includes(ext)) return 'audio';
  return 'file';
}

// ========== API ROUTES ==========

app.get('/api/state', (req, res) => {
  res.json(state);
});

// File upload
app.post('/api/upload', upload.single('file'), (req, res) => {
  if (!req.file) {
    return res.status(400).json({ error: 'No file uploaded.' });
  }
  const url = `/uploads/${req.file.filename}`;
  const mediaType = getMediaType(req.file.filename);
  res.json({ url, filename: req.file.filename, mediaType, size: req.file.size });
});

app.get('/app', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'app.html'));
});

// Auth
app.post('/api/auth/register', (req, res) => {
  const { name, email, password, role, location, avatar } = req.body;
  if (!name || !email || !password) {
    return res.status(400).json({ error: 'Name, email, and password are required.' });
  }

  const existing = state.auth.users.find((user) => user.email === email);
  if (existing) {
    return res.status(409).json({ error: 'An account with that email already exists.' });
  }

  const newUser = {
    id: `u${Date.now()}`,
    name,
    email,
    password,
    role: role || 'Creator',
    location: location || 'Remote',
    avatar: avatar || 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=300&q=80',
    coverPhoto: 'https://images.unsplash.com/photo-1519681393784-d120267933ba?auto=format&fit=crop&w=1200&q=80',
    headline: 'New to SocialSphere',
    website: '',
    joined: new Date().toLocaleString('default', { month: 'long', year: 'numeric' })
  };

  state.auth.users.push(newUser);
  state.users.push({
    id: newUser.id,
    name: newUser.name,
    role: newUser.role,
    avatar: newUser.avatar,
    coverPhoto: newUser.coverPhoto,
    location: newUser.location,
    headline: newUser.headline,
    website: newUser.website,
    joined: newUser.joined
  });
  state.user = { ...state.user, ...newUser, followers: state.user.followers, following: state.user.following, score: state.user.score };
  const token = `${newUser.id}-${Date.now()}`;
  state.auth.sessions.push({ token, userId: newUser.id });
  createNotification('system', `${newUser.name} joined SocialSphere. Welcome!`, 'System', '', '');
  broadcastState();
  res.status(201).json({ token, user: newUser });
});

app.post('/api/auth/login', (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) {
    return res.status(400).json({ error: 'Email and password are required.' });
  }

  const matchedUser = state.auth.users.find((user) => user.email === email && user.password === password);
  if (!matchedUser) {
    return res.status(401).json({ error: 'Invalid email or password.' });
  }

  state.user = {
    ...state.user,
    ...matchedUser,
    followers: state.user.followers,
    following: state.user.following,
    score: state.user.score
  };
  const token = `${matchedUser.id}-${Date.now()}`;
  state.auth.sessions = state.auth.sessions.filter((session) => session.userId !== matchedUser.id);
  state.auth.sessions.push({ token, userId: matchedUser.id });
  createNotification('system', `Welcome back, ${matchedUser.name}.`, 'System', '', '');
  broadcastState();
  res.json({ token, user: matchedUser });
});

app.post('/api/auth/logout', (req, res) => {
  const { token } = req.body;
  if (token) {
    state.auth.sessions = state.auth.sessions.filter((session) => session.token !== token);
  }
  broadcastState();
  res.json({ success: true });
});

// Posts
app.post('/api/posts', (req, res) => {
  const { content, image, privacy, mediaType, tags } = req.body;
  if (!content || !content.trim()) {
    return res.status(400).json({ error: 'Post content is required.' });
  }

  const post = {
    id: `p${Date.now()}`,
    author: getCurrentUser().name,
    userId: getCurrentUser().id,
    handle: '@' + getCurrentUser().name.toLowerCase().split(' ')[0],
    content: content.trim(),
    likes: 0,
    likedByMe: false,
    likedBy: [],
    comments: [],
    time: 'Just now',
    privacy: privacy || state.privacy.posts,
    image: image || '',
    mediaType: mediaType || (image ? 'image' : 'text'),
    tags: tags || []
  };

  state.posts.unshift(post);
  createNotification('system', 'Your post is now live for your selected audience.', 'System', '', '');
  broadcastState();
  res.json(post);
});

// Comments
app.post('/api/posts/:id/comments', (req, res) => {
  const { id } = req.params;
  const { text } = req.body;
  const post = state.posts.find((item) => item.id === id);

  if (!post || !text.trim()) {
    return res.status(400).json({ error: 'Comment text is required.' });
  }

  const comment = {
    id: `c${Date.now()}`,
    author: getCurrentUser().name,
    userId: getCurrentUser().id,
    text: text.trim(),
    time: 'Just now'
  };
  post.comments.push(comment);
  createNotification('comment', `${getCurrentUser().name} commented: "${text.substring(0, 50)}..."`, getCurrentUser().name, getCurrentUser().id, getCurrentUser().avatar);
  broadcastState();
  res.json(post);
});

// Like
app.post('/api/posts/:id/like', (req, res) => {
  const { id } = req.params;
  const post = state.posts.find((item) => item.id === id);

  if (!post) {
    return res.status(404).json({ error: 'Post not found.' });
  }

  const userId = getCurrentUser().id;
  if (post.likedBy.includes(userId)) {
    post.likedBy = post.likedBy.filter(uid => uid !== userId);
    post.likes -= 1;
    post.likedByMe = false;
  } else {
    post.likedBy.push(userId);
    post.likes += 1;
    post.likedByMe = true;
    createNotification('like', `${getCurrentUser().name} liked your post: "${post.content.substring(0, 40)}..."`, getCurrentUser().name, getCurrentUser().id, getCurrentUser().avatar);
  }

  broadcastState();
  res.json(post);
});

// Friend requests
app.post('/api/requests', (req, res) => {
  const { name, avatar } = req.body;
  state.requests.push({ id: `r${Date.now()}`, name: name || 'New User', avatar: avatar || 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=300&q=80', status: 'pending' });
  createNotification('friend_request', `${name || 'Someone'} wants to connect with you.`, name || 'Someone', '', avatar || '');
  broadcastState();
  res.json(state.requests[state.requests.length - 1]);
});

app.post('/api/requests/:id/accept', (req, res) => {
  const { id } = req.params;
  const request = state.requests.find((item) => item.id === id);

  if (!request) {
    return res.status(404).json({ error: 'Request not found.' });
  }

  request.status = 'accepted';
  state.user.followers += 1;
  createNotification('friend_accept', `${request.name} is now connected with you.`, request.name, request.userId || '', request.avatar);
  broadcastState();
  res.json(request);
});

app.post('/api/requests/:id/decline', (req, res) => {
  const { id } = req.params;
  state.requests = state.requests.filter((item) => item.id !== id);
  createNotification('system', 'Friend request declined.', 'System', '', '');
  broadcastState();
  res.json({ success: true });
});

// Profile
app.post('/api/profile', (req, res) => {
  const { name, avatar, coverPhoto, role, location, bio, website } = req.body;
  state.user = {
    ...state.user,
    name: name || state.user.name,
    avatar: avatar || state.user.avatar,
    coverPhoto: coverPhoto || state.user.coverPhoto,
    role: role || state.user.role,
    location: location || state.user.location,
    headline: bio || state.user.headline,
    website: website !== undefined ? website : state.user.website
  };
  const profileUser = state.users.find((user) => user.id === state.user.id);
  if (profileUser) {
    profileUser.name = state.user.name;
    profileUser.avatar = state.user.avatar;
    profileUser.coverPhoto = state.user.coverPhoto;
    profileUser.role = state.user.role;
    profileUser.location = state.user.location;
    profileUser.headline = state.user.headline;
    profileUser.website = state.user.website;
  }
  // Also update auth user
  const authUser = state.auth.users.find((user) => user.id === state.user.id);
  if (authUser) {
    authUser.name = state.user.name;
    authUser.avatar = state.user.avatar;
    authUser.coverPhoto = state.user.coverPhoto;
    authUser.role = state.user.role;
    authUser.location = state.user.location;
    authUser.headline = state.user.headline;
    authUser.website = state.user.website;
  }
  // Update in posts
  state.posts.forEach(p => {
    if (p.userId === state.user.id) {
      p.author = state.user.name;
    }
  });
  createNotification('system', 'Profile updated successfully.', 'System', '', '');
  broadcastState();
  res.json(state.user);
});

// Follow / Unfollow
app.post('/api/users/:id/follow', (req, res) => {
  const { id } = req.params;
  const targetUser = state.users.find(u => u.id === id);
  if (!targetUser) return res.status(404).json({ error: 'User not found.' });

  const alreadyFollowing = state.user.followingList.find(u => u.id === id);
  if (alreadyFollowing) {
    state.user.followingList = state.user.followingList.filter(u => u.id !== id);
    state.user.following -= 1;
    createNotification('system', `Unfollowed ${targetUser.name}.`, 'System', '', '');
  } else {
    state.user.followingList.push({
      id: targetUser.id,
      name: targetUser.name,
      avatar: targetUser.avatar,
      role: targetUser.role
    });
    state.user.following += 1;
    createNotification('system', `You followed ${targetUser.name}.`, 'System', '', '');
  }
  broadcastState();
  res.json({ following: state.user.following, followingList: state.user.followingList });
});

// Social management
app.post('/api/social/friends/:id/remove', (req, res) => {
  const { id } = req.params;
  state.social.friends = state.social.friends.filter((friend) => friend.id !== id);
  state.social.favorites = state.social.favorites.filter((friend) => friend.id !== id);
  createNotification('system', 'Friend removed from your list.', 'System', '', '');
  broadcastState();
  res.json(state.social);
});

app.post('/api/social/favorites/:id/toggle', (req, res) => {
  const { id } = req.params;
  const friend = state.social.friends.find((item) => item.id === id);
  if (!friend) {
    return res.status(404).json({ error: 'Friend not found.' });
  }

  const existing = state.social.favorites.find((item) => item.id === id);
  if (existing) {
    state.social.favorites = state.social.favorites.filter((item) => item.id !== id);
  } else {
    state.social.favorites.push(friend);
  }

  createNotification('system', existing ? 'Removed from favorites.' : 'Added to favorites.', 'System', '', '');
  broadcastState();
  res.json(state.social);
});

app.post('/api/social/blocked/:id/toggle', (req, res) => {
  const { id } = req.params;
  const existing = state.social.blocked.find((item) => item.id === id);
  if (existing) {
    state.social.blocked = state.social.blocked.filter((item) => item.id !== id);
  } else {
    const friend = state.social.friends.find((item) => item.id === id) || state.users.find((user) => user.id === id);
    if (friend) {
      state.social.blocked.push(friend);
    }
  }

  createNotification('system', existing ? 'User unblocked.' : 'User blocked.', 'System', '', '');
  broadcastState();
  res.json(state.social);
});

// Chats
app.post('/api/chats', (req, res) => {
  const { participant, participantId, text } = req.body;
  let chat = state.chats.find((item) => item.participant === participant || item.participantId === participantId);

  if (!chat) {
    const avatar = state.users.find(u => u.id === participantId || u.name === participant)?.avatar || '';
    chat = {
      id: `chat-${Date.now()}`,
      participant: participant,
      participantId: participantId || `u${Date.now()}`,
      avatar: avatar,
      status: 'offline',
      messages: []
    };
    state.chats.unshift(chat);
  }

  chat.messages.push({
    id: `m${Date.now()}`,
    author: 'You',
    authorId: getCurrentUser().id,
    text,
    time: 'Now',
    read: false
  });
  createNotification('messages', `New message sent to ${participant}.`, participant, participantId, chat.avatar);
  broadcastState();
  res.json(chat);
});

// Mark messages as read
app.post('/api/chats/:id/read', (req, res) => {
  const { id } = req.params;
  const chat = state.chats.find(c => c.id === id);
  if (chat) {
    chat.messages.forEach(m => { if (m.author !== 'You') m.read = true; });
    broadcastState();
  }
  res.json({ success: true });
});

// Privacy
app.post('/api/privacy', (req, res) => {
  state.privacy = { ...state.privacy, ...req.body };
  createNotification('system', 'Privacy settings updated.', 'System', '', '');
  broadcastState();
  res.json(state.privacy);
});

// Notification preferences
app.post('/api/notifications/preferences', (req, res) => {
  state.notificationPreferences = { ...state.notificationPreferences, ...req.body };
  createNotification('system', 'Notification preferences updated.', 'System', '', '');
  broadcastState();
  res.json(state.notificationPreferences);
});

// Mark all notifications as read
app.post('/api/notifications/read-all', (req, res) => {
  state.notifications.forEach(n => n.read = true);
  broadcastState();
  res.json({ success: true });
});

// Search
app.get('/api/search', (req, res) => {
  const q = (req.query.q || '').toLowerCase().trim();
  if (!q) return res.json({ users: [], posts: [], hashtags: [] });

  const users = state.users.filter(u => u.name.toLowerCase().includes(q) || u.role.toLowerCase().includes(q) || (u.headline && u.headline.toLowerCase().includes(q)));
  const posts = state.posts.filter(p => p.content.toLowerCase().includes(q) || p.tags.some(t => t.toLowerCase().includes(q)));
  const hashtags = state.trending.filter(t => t.tag.toLowerCase().includes(q));

  res.json({ users, posts, hashtags });
});

// Catch-all
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'login.html'));
});

// ========== WEB SOCKET ==========

io.on('connection', (socket) => {
  console.log('Socket connected:', socket.id);

  // Send initial state
  socket.emit('state:update', state);
  socket.emit('notification:new', { type: 'system', text: 'Realtime sync connected.' });

  // Track online user
  socket.on('user:online', (userId) => {
    if (userId) {
      onlineUsers.set(socket.id, userId);
      // Update friend statuses
      state.social.friends.forEach(f => {
        if (f.id === userId) f.status = 'online';
      });
      io.emit('users:online', Array.from(onlineUsers.values()));
      io.emit('state:update', state);
    }
  });

  // Join a chat room
  socket.on('chat:join', (chatId) => {
    socket.join(`chat:${chatId}`);
  });

  // Leave a chat room
  socket.on('chat:leave', (chatId) => {
    socket.leave(`chat:${chatId}`);
  });

  // Send message via WebSocket
  socket.on('chat:message', (data) => {
    const { chatId, text, participant, participantId, avatar } = data;
    let chat = state.chats.find(c => c.id === chatId || c.participantId === participantId);
    
    if (!chat) {
      chat = {
        id: `chat-${Date.now()}`,
        participant: participant,
        participantId: participantId || `u${Date.now()}`,
        avatar: avatar || '',
        status: 'offline',
        messages: []
      };
      state.chats.unshift(chat);
    }

    const msg = {
      id: `m${Date.now()}`,
      author: 'You',
      authorId: getCurrentUser().id,
      text,
      time: 'Now',
      read: false
    };
    chat.messages.push(msg);

    // Broadcast to chat room
    io.to(`chat:${chat.id}`).emit('chat:message', chat);
    io.to(`chat:${chat.id}`).emit('chat:typing', { chatId: chat.id, userId: null });

    // Update state for all clients
    io.emit('state:update', state);
  });

  // Typing indicator
  socket.on('chat:typing', (data) => {
    const { chatId, userId, userName } = data;
    socket.to(`chat:${chatId}`).emit('chat:typing', { chatId, userId, userName });
  });

  // Stop typing
  socket.on('chat:typing:stop', (data) => {
    const { chatId, userId } = data;
    socket.to(`chat:${chatId}`).emit('chat:typing', { chatId, userId: null });
  });

  // Disconnect
  socket.on('disconnect', () => {
    const userId = onlineUsers.get(socket.id);
    if (userId) {
      state.social.friends.forEach(f => {
        if (f.id === userId) f.status = 'offline';
      });
      onlineUsers.delete(socket.id);
      io.emit('users:online', Array.from(onlineUsers.values()));
      io.emit('state:update', state);
    }
    console.log('Socket disconnected:', socket.id);
  });
});

// ========== SERVER ==========

function startServer(port = process.env.PORT || 3000) {
  return new Promise((resolve) => {
    serverInstance = server.listen(port, () => resolve(server));
  });
}

function stopServer() {
  return new Promise((resolve) => {
    if (serverInstance) {
      serverInstance.close(() => resolve());
    } else {
      resolve();
    }
  });
}

if (require.main === module) {
  const port = process.env.PORT || 3000;
  startServer(port).then(() => {
    console.log(`Social platform listening on http://localhost:${port}`);
  });
}

module.exports = { app, server, startServer, stopServer };

