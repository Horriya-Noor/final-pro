const socket = io();
let state = null;
let typingTimeouts = {};
let activeChatId = null;

function escapeHtml(value) {
  return String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '<')
    .replace(/>/g, '>')
    .replace(/"/g, '"')
    .replace(/'/g, '&#39;');
}

function getMediaEmbed(url, mediaType) {
  if (!url) return '';
  const ext = url.split('.').pop().toLowerCase();
  const type = mediaType || (['mp4', 'webm', 'ogg'].includes(ext) ? 'video' : ['mp3', 'wav'].includes(ext) ? 'audio' : 'image');
  
  if (type === 'video') {
    return `<video class="post-video" controls><source src="${escapeHtml(url)}" type="video/mp4">Your browser does not support video.</video>`;
  } else if (type === 'audio') {
    return `<audio class="post-audio" controls><source src="${escapeHtml(url)}" type="audio/mpeg">Your browser does not support audio.</audio>`;
  } else if (type === 'image') {
    return `<img class="post-image" src="${escapeHtml(url)}" alt="Post media" loading="lazy" />`;
  }
  return '';
}

function formatFileSize(bytes) {
  if (bytes < 1024) return bytes + ' B';
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
  return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
}

async function loadState() {
  try {
    const response = await fetch('/api/state');
    state = await response.json();
    render();
  } catch (e) {
    console.error('Failed to load state:', e);
  }
}

function setView(view) {
  const preview = document.getElementById('focus-preview');
  if (!preview) return;
  const titles = {
    feed: { title: 'Curated feed', body: 'Jump straight into the latest stories, quick reactions, and fresh conversations.' },
    signals: { title: 'Realtime signals', body: 'Monitor live updates, new notifications, and fast-moving social activity.' },
    people: { title: 'People and circles', body: 'Keep your network close with favorites, requests, and direct messages in one place.' }
  };
  const current = titles[view] || titles.feed;
  preview.innerHTML = `<div><h4>${current.title}</h4><p>${current.body}</p></div>`;
  document.querySelectorAll('.focus-pill').forEach((button) => {
    button.classList.toggle('active', button.dataset.view === view);
  });
}

function showToast(message) {
  const existing = document.querySelector('.toast');
  if (existing) existing.remove();
  const toast = document.createElement('div');
  toast.className = 'toast';
  toast.textContent = message;
  document.body.appendChild(toast);
  window.setTimeout(() => toast.remove(), 1800);
}

function render() {
  if (!state) return;
  const u = state.user;

  // Profile section
  const avatar = document.getElementById('profile-avatar');
  if (avatar) avatar.src = u.avatar;
  const cover = document.getElementById('profile-cover');
  if (cover) cover.src = u.coverPhoto || 'https://images.unsplash.com/photo-1519681393784-d120267933ba?auto=format&fit=crop&w=1200&q=80';

  const profileName = document.getElementById('profile-name');
  if (profileName) profileName.textContent = u.name;
  const profileRole = document.getElementById('profile-role');
  if (profileRole) profileRole.textContent = u.role;
  const profileLocation = document.getElementById('profile-location');
  if (profileLocation) profileLocation.textContent = u.location;
  const profileHeadline = document.getElementById('profile-headline');
  if (profileHeadline) profileHeadline.textContent = u.headline;
  const profileWebsite = document.getElementById('profile-website');
  if (profileWebsite) profileWebsite.textContent = u.website || '';
  if (profileWebsite) profileWebsite.href = u.website || '#';
  const profileJoined = document.getElementById('profile-joined');
  if (profileJoined) profileJoined.textContent = 'Joined ' + (u.joined || 'March 2022');

  const followerCount = document.getElementById('follower-count');
  if (followerCount) followerCount.textContent = u.followers;
  const followingCount = document.getElementById('following-count');
  if (followingCount) followingCount.textContent = u.following;
  const scoreCount = document.getElementById('score-count');
  if (scoreCount) scoreCount.textContent = `${u.score}%`;

  // Notification badge
  const unreadCount = state.notifications.filter(n => !n.read).length;
  const badge = document.getElementById('notification-badge');
  if (badge) {
    badge.textContent = unreadCount > 0 ? (unreadCount > 99 ? '99+' : unreadCount) : '';
    badge.style.display = unreadCount > 0 ? 'flex' : 'none';
  }

  // Profile edit form
  const nameField = document.querySelector('#profile-edit-form [name="name"]');
  if (nameField) nameField.value = u.name;
  const avatarField = document.querySelector('#profile-edit-form [name="avatar"]');
  if (avatarField) avatarField.value = u.avatar;
  const coverField = document.querySelector('#profile-edit-form [name="coverPhoto"]');
  if (coverField) coverField.value = u.coverPhoto || '';
  const roleField = document.querySelector('#profile-edit-form [name="role"]');
  if (roleField) roleField.value = u.role;
  const locationField = document.querySelector('#profile-edit-form [name="location"]');
  if (locationField) locationField.value = u.location;
  const bioField = document.querySelector('#profile-edit-form [name="bio"]');
  if (bioField) bioField.value = u.headline;
  const websiteField = document.querySelector('#profile-edit-form [name="website"]');
  if (websiteField) websiteField.value = u.website || '';

  // Privacy form
  const postsField = document.querySelector('#privacy-form [name="posts"]');
  if (postsField) postsField.value = state.privacy.posts;
  const messagesField = document.querySelector('#privacy-form [name="messages"]');
  if (messagesField) messagesField.value = state.privacy.messages;
  const profileField = document.querySelector('#privacy-form [name="profile"]');
  if (profileField) profileField.value = state.privacy.profile;

  // Notification preferences
  const notifPrefs = state.notificationPreferences || {};
  document.querySelectorAll('[data-notif-pref]').forEach(el => {
    const key = el.dataset.notifPref;
    if (el.type === 'checkbox') {
      el.checked = notifPrefs[key] !== false;
    }
  });

  // Feed
  const feed = document.getElementById('feed');
  if (feed) {
    feed.innerHTML = state.posts.map((post) => {
      const mediaHtml = post.image ? getMediaEmbed(post.image, post.mediaType) : '';
      const tagsHtml = (post.tags || []).map(t => `<button class="tag-chip hashtag-btn" data-tag="${escapeHtml(t)}">${escapeHtml(t)}</button>`).join(' ');
      return `
      <article class="post-card">
        <div class="post-meta">
          <div class="post-author">
            <img class="mini-avatar" src="${escapeHtml(state.users.find(u => u.id === post.userId)?.avatar || '')}" alt="" />
            <div>
              <strong>${escapeHtml(post.author)}</strong>
              <span>${escapeHtml(post.handle)} · ${escapeHtml(post.time)}</span>
            </div>
          </div>
          <span class="privacy-badge">${escapeHtml(post.privacy)}</span>
        </div>
        <div class="post-content">${escapeHtml(post.content)}</div>
        ${tagsHtml ? `<div class="tag-row">${tagsHtml}</div>` : ''}
        ${mediaHtml}
        <div class="post-actions">
          <button class="action-btn like-btn ${post.likedByMe ? 'active' : ''}" data-post-id="${post.id}">♥ ${post.likes}</button>
          <button class="action-btn" type="button">💬 ${post.comments.length}</button>
        </div>
        <form class="comment-form" data-post-id="${post.id}">
          <input name="comment" placeholder="Write a comment..." />
          <button type="submit">Send</button>
        </form>
        <div class="comment-list">
          ${post.comments.map((comment) => {
            const commentUser = state.users.find(u => u.id === comment.userId);
            return `<div class="comment-item">
              ${commentUser ? `<img class="mini-avatar mini-avatar-sm" src="${escapeHtml(commentUser.avatar)}" alt="" />` : ''}
              <div><strong>${escapeHtml(comment.author)}:</strong> ${escapeHtml(comment.text)}</div>
            </div>`;
          }).join('')}
        </div>
      </article>
    `}).join('');
  }

  // Hashtag click handlers
  document.querySelectorAll('.hashtag-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const tag = btn.dataset.tag;
      const searchInput = document.getElementById('search-input');
      if (searchInput) {
        searchInput.value = tag;
        doSearch(tag);
      }
    });
  });

  // Requests
  const requests = document.getElementById('requests');
  if (requests) {
    requests.innerHTML = state.requests.map((request) => `
      <div class="request-card">
        <div class="profile-top">
          <img src="${escapeHtml(request.avatar)}" alt="Avatar" />
          <div>
            <strong>${escapeHtml(request.name)}</strong>
            <p>${request.status === 'accepted' ? '✅ Connected' : '⏳ Pending'}</p>
          </div>
        </div>
        <div class="post-actions">
          ${request.status === 'pending' ? `
            <button class="action-btn accept-btn" data-request-id="${request.id}" data-action="accept">✓ Accept</button>
            <button class="action-btn decline-btn" data-request-id="${request.id}" data-action="decline">✕ Decline</button>
          ` : ''}
        </div>
      </div>
    `).join('');
  }

  // Notifications
  const notifications = document.getElementById('notifications');
  if (notifications) {
    const typeIcons = {
      friend_request: '👋',
      friend_accept: '✅',
      like: '♥',
      comment: '💬',
      mention: '@',
      system: '🔔',
      messages: '✉️'
    };
    notifications.innerHTML = state.notifications.map((item) => `
      <div class="notification-card ${item.read ? '' : 'unread'}">
        <div class="notif-icon">${typeIcons[item.type] || '🔔'}</div>
        <div class="notif-content">
          <strong>${escapeHtml(item.text)}</strong>
          <p class="muted">${escapeHtml(item.time)}</p>
        </div>
        ${!item.read ? '<span class="unread-dot"></span>' : ''}
      </div>
    `).join('');
  }

  // Chat list
  const chatList = document.getElementById('chat-list');
  if (chatList) {
    chatList.innerHTML = state.chats.map((chat) => {
      const unreadCount = chat.messages.filter(m => m.author !== 'You' && !m.read).length;
      const lastMsg = chat.messages[chat.messages.length - 1];
      return `
      <div class="chat-card ${activeChatId === chat.id ? 'active-chat' : ''}" data-chat-id="${chat.id}">
        <div class="chat-header">
          <div class="chat-avatar-wrapper">
            <img class="mini-avatar" src="${escapeHtml(chat.avatar || '')}" alt="" />
            <span class="online-dot ${chat.status === 'online' ? 'online' : 'offline'}"></span>
          </div>
          <div class="chat-info">
            <strong>${escapeHtml(chat.participant)}</strong>
            ${lastMsg ? `<p class="muted chat-preview">${escapeHtml(lastMsg.text.substring(0, 30))}${lastMsg.text.length > 30 ? '...' : ''}</p>` : ''}
          </div>
          ${unreadCount > 0 ? `<span class="chat-badge">${unreadCount}</span>` : ''}
        </div>
      </div>
    `}).join('');
  }

  // Chat messages
  const messageContainer = document.getElementById('message-container');
  if (messageContainer && activeChatId) {
    const chat = state.chats.find(c => c.id === activeChatId);
    if (chat) {
      messageContainer.innerHTML = chat.messages.map(m => `
        <div class="message-bubble ${m.author === 'You' ? 'self' : ''}">
          <div class="msg-text">${escapeHtml(m.text)}</div>
          <div class="msg-meta">
            <span class="msg-time">${escapeHtml(m.time)}</span>
            ${m.author === 'You' ? `<span class="msg-read ${m.read ? 'read' : ''}">${m.read ? '✓✓' : '✓'}</span>` : ''}
          </div>
        </div>
      `).join('');
      messageContainer.scrollTop = messageContainer.scrollHeight;
    }
  }

  // Online users list
  const onlineUsers = document.getElementById('online-users');
  if (onlineUsers) {
    const onlineFriends = state.social.friends.filter(f => f.status === 'online');
    onlineUsers.innerHTML = onlineFriends.map(f => `
      <div class="online-user-item">
        <span class="online-dot online"></span>
        <span>${escapeHtml(f.name)}</span>
      </div>
    `).join('') || '<p class="muted">No friends online</p>';
  }

  // Friend list
  const friendList = document.getElementById('friend-list');
  if (friendList) {
    friendList.innerHTML = (state.social?.friends || []).map((friend) => `
      <div class="request-card">
        <div class="profile-top">
          <div class="chat-avatar-wrapper">
            <img src="${escapeHtml(friend.avatar)}" alt="Avatar" />
            <span class="online-dot ${friend.status === 'online' ? 'online' : 'offline'}"></span>
          </div>
          <div>
            <strong>${escapeHtml(friend.name)}</strong>
            <p>${friend.status === 'online' ? '🟢 Online' : '⚫ Offline'}</p>
          </div>
        </div>
        <div class="post-actions">
          <button class="action-btn" data-friend-id="${friend.id}" data-action="favorite">★ Favorite</button>
          <button class="action-btn" data-friend-id="${friend.id}" data-action="block">⛔ Block</button>
          <button class="action-btn" data-friend-id="${friend.id}" data-action="remove">Remove</button>
        </div>
      </div>
    `).join('');
  }

  // Favorites
  const favoriteList = document.getElementById('favorite-list');
  if (favoriteList) {
    favoriteList.innerHTML = (state.social?.favorites || []).map((friend) => `
      <div class="notification-card">
        <div class="profile-top">
          <img src="${escapeHtml(friend.avatar)}" alt="Avatar" />
          <div>
            <strong>${escapeHtml(friend.name)}</strong>
            <p class="muted">★ Favorite contact</p>
          </div>
        </div>
      </div>
    `).join('');
  }

  // Blocked
  const blockedList = document.getElementById('blocked-list');
  if (blockedList) {
    blockedList.innerHTML = (state.social?.blocked || []).map((friend) => `
      <div class="notification-card">
        <div class="profile-top">
          <img src="${escapeHtml(friend.avatar)}" alt="Avatar" />
          <div>
            <strong>${escapeHtml(friend.name)}</strong>
            <p class="muted">⛔ Blocked</p>
          </div>
        </div>
        <button class="action-btn" data-friend-id="${friend.id}" data-action="unblock">Unblock</button>
      </div>
    `).join('');
  }

  // Followers / Following lists for profile page
  const followersList = document.getElementById('followers-list');
  if (followersList) {
    followersList.innerHTML = (state.user.followersList || []).map(f => `
      <div class="person-card">
        <div class="profile-top">
          <img src="${escapeHtml(f.avatar)}" alt="" />
          <div>
            <strong>${escapeHtml(f.name)}</strong>
            <p class="muted">${escapeHtml(f.role || '')}</p>
          </div>
        </div>
        <button class="action-btn" data-user-id="${f.id}" data-action="follow">Following</button>
      </div>
    `).join('') || '<p class="muted">No followers yet</p>';
  }

  const followingList = document.getElementById('following-list');
  if (followingList) {
    followingList.innerHTML = (state.user.followingList || []).map(f => `
      <div class="person-card">
        <div class="profile-top">
          <img src="${escapeHtml(f.avatar)}" alt="" />
          <div>
            <strong>${escapeHtml(f.name)}</strong>
            <p class="muted">${escapeHtml(f.role || '')}</p>
          </div>
        </div>
        <button class="action-btn" data-user-id="${f.id}" data-action="follow">Following</button>
      </div>
    `).join('') || '<p class="muted">Not following anyone yet</p>';
  }

  // Trending / explore
  const trendingList = document.getElementById('trending-list');
  if (trendingList) {
    trendingList.innerHTML = (state.trending || []).map(t => `
      <button class="tag-chip hashtag-btn" data-tag="${escapeHtml(t.tag)}">
        ${escapeHtml(t.tag)} <span class="muted">${t.count}</span>
      </button>
    `).join('');
  }

  // Suggested users
  const suggestedUsers = document.getElementById('suggested-users');
  if (suggestedUsers) {
    const excludedIds = ['u1', ...state.social.friends.map(f => f.id), ...state.social.blocked.map(b => b.id)];
    const suggestions = state.users.filter(u => !excludedIds.includes(u.id)).slice(0, 5);
    suggestedUsers.innerHTML = suggestions.map(u => `
      <div class="person-card">
        <div class="profile-top">
          <img src="${escapeHtml(u.avatar)}" alt="" />
          <div>
            <strong>${escapeHtml(u.name)}</strong>
            <p class="muted">${escapeHtml(u.role || '')}</p>
          </div>
        </div>
        <button class="action-btn follow-btn" data-user-id="${u.id}" data-action="follow">Follow</button>
      </div>
    `).join('') || '<p class="muted">No suggestions right now</p>';
  }

  // Connection status
  const status = document.getElementById('connection-status');
  if (status) {
    status.textContent = '🟢 Connected';
  }

  // Profile page recent posts
  const profilePosts = document.getElementById('profile-posts');
  if (profilePosts) {
    const myPosts = state.posts.filter(p => p.userId === state.user.id);
    profilePosts.innerHTML = myPosts.map(p => `
      <div class="activity-row">
        <div>
          <strong>${escapeHtml(p.content.substring(0, 60))}${p.content.length > 60 ? '...' : ''}</strong>
          <p class="muted">${p.likes} likes · ${p.comments.length} comments · ${p.time}</p>
        </div>
        <span class="privacy-badge">${escapeHtml(p.privacy)}</span>
      </div>
    `).join('') || '<div class="activity-row"><p class="muted">No posts yet</p></div>';
  }

  // Typing indicator in chat
  const typingIndicator = document.getElementById('typing-indicator');
  if (typingIndicator && activeChatId) {
    // Handled by socket events
  }
}

// ========== EVENT HANDLERS ==========

async function createPost(event) {
  event.preventDefault();
  const form = event.currentTarget;
  const payload = {
    content: form.content.value,
    image: form.image.value,
    privacy: form.privacy.value,
    mediaType: form.image.value ? (form.image.value.match(/\.(mp4|webm|ogg)$/i) ? 'video' : form.image.value.match(/\.(mp3|wav)$/i) ? 'audio' : 'image') : 'text',
    tags: form.content.value.match(/#\w+/g) || []
  };

  const response = await fetch('/api/posts', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  });

  if (response.ok) {
    form.reset();
    showToast('Post published!');
  }
}

async function createComment(event) {
  event.preventDefault();
  const form = event.currentTarget;
  const postId = form.dataset.postId;
  const response = await fetch(`/api/posts/${postId}/comments`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ text: form.comment.value })
  });

  if (response.ok) {
    form.reset();
  }
}

async function toggleLike(event) {
  const button = event.target.closest('.like-btn');
  if (!button) return;
  const postId = button.dataset.postId;
  await fetch(`/api/posts/${postId}/like`, { method: 'POST' });
}

async function handleRequest(event) {
  const button = event.target.closest('[data-action="accept"], [data-action="decline"]');
  if (!button) return;
  const action = button.dataset.action;
  const id = button.dataset.requestId;
  
  if (action === 'accept') {
    await fetch(`/api/requests/${id}/accept`, { method: 'POST' });
    showToast('Friend request accepted!');
  } else {
    await fetch(`/api/requests/${id}/decline`, { method: 'POST' });
    showToast('Friend request declined.');
  }
}

async function sendRequest(event) {
  event.preventDefault();
  const form = event.currentTarget;
  const payload = {
    name: form.name.value,
    avatar: form.avatar.value || 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=300&q=80'
  };

  await fetch('/api/requests', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  });
  form.reset();
  showToast('Friend request sent!');
}

async function handleAuth(event) {
  event.preventDefault();
  const form = event.currentTarget;
  const payload = {
    email: form.email.value,
    password: form.password.value
  };

  let response;
  if (form.mode.value === 'register') {
    payload.name = form.name.value;
    response = await fetch('/api/auth/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
  } else {
    response = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
  }

  if (response.ok) {
    window.location.href = '/app';
  } else {
    const data = await response.json().catch(() => ({}));
    const feedback = document.querySelector('.auth-hints');
    if (feedback) {
      feedback.innerHTML = `<p class="error-text">${data.error || 'Authentication failed.'}</p>`;
    }
  }

  form.reset();
}

async function logout() {
  await fetch('/api/auth/logout', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ token: 'session' })
  });
  window.location.href = '/';
}

async function updateProfile(event) {
  event.preventDefault();
  const form = event.currentTarget;
  const payload = {
    name: form.name.value,
    avatar: form.avatar.value,
    coverPhoto: form.coverPhoto?.value || '',
    role: form.role.value,
    location: form.location.value,
    bio: form.bio.value,
    website: form.website?.value || ''
  };

  await fetch('/api/profile', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  });
  showToast('Profile updated!');
}

async function updatePrivacy(event) {
  event.preventDefault();
  const form = event.currentTarget;
  const payload = {
    posts: form.posts.value,
    messages: form.messages.value,
    profile: form.profile.value
  };

  await fetch('/api/privacy', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  });
  showToast('Privacy settings saved!');
}

async function manageSocial(event) {
  const button = event.target.closest('[data-action]');
  if (!button) return;
  const action = button.dataset.action;
  const friendId = button.dataset.friendId;
  const userId = button.dataset.userId;

  const targetId = friendId || userId;

  if (action === 'remove') {
    await fetch(`/api/social/friends/${targetId}/remove`, { method: 'POST' });
    showToast('Friend removed.');
  } else if (action === 'favorite') {
    await fetch(`/api/social/favorites/${targetId}/toggle`, { method: 'POST' });
    showToast('Favorite toggled.');
  } else if (action === 'block') {
    await fetch(`/api/social/blocked/${targetId}/toggle`, { method: 'POST' });
    showToast('User blocked.');
  } else if (action === 'unblock') {
    await fetch(`/api/social/blocked/${targetId}/toggle`, { method: 'POST' });
    showToast('User unblocked.');
  } else if (action === 'follow') {
    await fetch(`/api/users/${targetId}/follow`, { method: 'POST' });
    showToast('Follow toggled.');
  }
}

async function sendDirectMessage(event) {
  event.preventDefault();
  const form = event.currentTarget;
  const payload = {
    participant: form.participant.value,
    participantId: form.participantId?.value || '',
    text: form.text.value
  };

  const response = await fetch('/api/chats', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  });

  if (response.ok) {
    form.reset();
    showToast('Message sent!');
  }
}

async function sendChatMessage(event) {
  event.preventDefault();
  const form = event.currentTarget;
  const text = form['chat-message']?.value || form.text?.value;
  if (!text || !text.trim() || !activeChatId) return;

  const chat = state.chats.find(c => c.id === activeChatId);
  if (!chat) return;

  // Send via WebSocket for real-time delivery
  socket.emit('chat:message', {
    chatId: activeChatId,
    text: text.trim(),
    participant: chat.participant,
    participantId: chat.participantId,
    avatar: chat.avatar
  });

  form.reset();
}

function openChat(chatId) {
  activeChatId = chatId;
  
  // Leave previous chat room
  if (activeChatId) socket.emit('chat:leave', activeChatId);
  
  // Join new chat room
  socket.emit('chat:join', chatId);
  
  // Mark messages as read
  fetch(`/api/chats/${chatId}/read`, { method: 'POST' });

  // Render messages
  render();
  
  // Show message area
  const msgArea = document.getElementById('message-area');
  const chatView = document.getElementById('chat-view');
  if (msgArea) msgArea.style.display = 'block';
  if (chatView) chatView.style.display = 'block';
}

function doSearch(query) {
  const q = query || document.getElementById('search-input')?.value || '';
  if (!q.trim()) return;

  fetch(`/api/search?q=${encodeURIComponent(q.trim())}`)
    .then(r => r.json())
    .then(data => {
      const results = document.getElementById('search-results');
      if (!results) return;
      
      let html = '';
      if (data.users.length > 0) {
        html += `<h4>Users</h4>`;
        data.users.forEach(u => {
          html += `<div class="person-card"><div class="profile-top"><img src="${escapeHtml(u.avatar)}" alt="" /><div><strong>${escapeHtml(u.name)}</strong><p class="muted">${escapeHtml(u.role || '')}</p></div></div></div>`;
        });
      }
      if (data.posts.length > 0) {
        html += `<h4>Posts</h4>`;
        data.posts.forEach(p => {
          html += `<div class="activity-row"><strong>${escapeHtml(p.author)}:</strong><p class="muted">${escapeHtml(p.content.substring(0, 80))}${p.content.length > 80 ? '...' : ''}</p></div>`;
        });
      }
      if (data.hashtags.length > 0) {
        html += `<h4>Hashtags</h4><div class="tag-row">`;
        data.hashtags.forEach(t => {
          html += `<button class="tag-chip hashtag-btn" data-tag="${escapeHtml(t.tag)}">${escapeHtml(t.tag)} (${t.count})</button>`;
        });
        html += `</div>`;
      }
      if (!html) html = '<p class="muted">No results found.</p>';
      results.innerHTML = html;
      results.style.display = 'block';

      // Bind hashtag clicks in results
      results.querySelectorAll('.hashtag-btn').forEach(btn => {
        btn.addEventListener('click', () => {
          document.getElementById('search-input').value = btn.dataset.tag;
          doSearch(btn.dataset.tag);
        });
      });
    });
}

async function uploadFile(file) {
  const formData = new FormData();
  formData.append('file', file);

  try {
    const response = await fetch('/api/upload', {
      method: 'POST',
      body: formData
    });
    const data = await response.json();
    if (response.ok) {
      // Insert the uploaded file URL into the post composer
      const imageInput = document.querySelector('#composer [name="image"]');
      if (imageInput) {
        imageInput.value = data.url;
      }
      showToast(`Uploaded: ${formatFileSize(data.size)}`);
    } else {
      showToast('Upload failed: ' + (data.error || 'Unknown error'));
    }
  } catch (e) {
    showToast('Upload error');
  }
}

// ========== FILE UPLOAD DRAG-DROP ==========

function setupFileUpload() {
  const dropZone = document.getElementById('upload-zone');
  if (!dropZone) return;

  dropZone.addEventListener('dragover', (e) => {
    e.preventDefault();
    dropZone.classList.add('dragover');
  });

  dropZone.addEventListener('dragleave', () => {
    dropZone.classList.remove('dragover');
  });

  dropZone.addEventListener('drop', (e) => {
    e.preventDefault();
    dropZone.classList.remove('dragover');
    const files = e.dataTransfer.files;
    if (files.length > 0) uploadFile(files[0]);
  });

  dropZone.addEventListener('click', () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/*,video/*,audio/*,.pdf,.doc,.docx,.txt';
    input.onchange = (e) => {
      if (e.target.files.length > 0) uploadFile(e.target.files[0]);
    };
    input.click();
  });
}

async function saveNotificationPrefs(event) {
  event.preventDefault();
  const prefs = {};
  document.querySelectorAll('[data-notif-pref]').forEach(el => {
    prefs[el.dataset.notifPref] = el.checked;
  });

  await fetch('/api/notifications/preferences', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(prefs)
  });
  showToast('Preferences saved!');
}

async function markAllNotificationsRead() {
  await fetch('/api/notifications/read-all', { method: 'POST' });
  showToast('All notifications marked as read!');
}

// ========== BIND EVENT LISTENERS ==========

const composer = document.getElementById('composer');
if (composer) composer.addEventListener('submit', createPost);

const feed = document.getElementById('feed');
if (feed) {
  feed.addEventListener('submit', (event) => {
    if (event.target.classList.contains('comment-form')) createComment(event);
  });
  feed.addEventListener('click', toggleLike);
}

const requests = document.getElementById('requests');
if (requests) requests.addEventListener('click', handleRequest);

const requestForm = document.getElementById('request-form');
if (requestForm) requestForm.addEventListener('submit', sendRequest);

const authForm = document.getElementById('auth-form');
if (authForm) authForm.addEventListener('submit', handleAuth);

const logoutButton = document.getElementById('logout-btn');
if (logoutButton) logoutButton.addEventListener('click', logout);

const profileForm = document.getElementById('profile-edit-form');
if (profileForm) profileForm.addEventListener('submit', updateProfile);

const privacyForm = document.getElementById('privacy-form');
if (privacyForm) privacyForm.addEventListener('submit', updatePrivacy);

const friendList = document.getElementById('friend-list');
if (friendList) friendList.addEventListener('click', manageSocial);

const blockedList = document.getElementById('blocked-list');
if (blockedList) blockedList.addEventListener('click', manageSocial);

const followersList = document.getElementById('followers-list');
if (followersList) followersList.addEventListener('click', manageSocial);

const followingList = document.getElementById('following-list');
if (followingList) followingList.addEventListener('click', manageSocial);

const suggestedUsers = document.getElementById('suggested-users');
if (suggestedUsers) suggestedUsers.addEventListener('click', manageSocial);

const chatForm = document.getElementById('chat-form');
if (chatForm) chatForm.addEventListener('submit', sendDirectMessage);

const chatMessageForm = document.getElementById('chat-message-form');
if (chatMessageForm) chatMessageForm.addEventListener('submit', sendChatMessage);

// Chat list click to open
const chatList = document.getElementById('chat-list');
if (chatList) {
  chatList.addEventListener('click', (event) => {
    const card = event.target.closest('.chat-card');
    if (card) {
      openChat(card.dataset.chatId);
    }
  });
}

// Search handler
const searchInput = document.getElementById('search-input');
if (searchInput) {
  let searchTimeout;
  searchInput.addEventListener('input', () => {
    clearTimeout(searchTimeout);
    searchTimeout = setTimeout(() => doSearch(searchInput.value), 300);
  });
  searchInput.addEventListener('blur', () => {
    setTimeout(() => {
      const results = document.getElementById('search-results');
      if (results) results.style.display = 'none';
    }, 200);
  });
  searchInput.addEventListener('focus', () => {
    if (searchInput.value.trim()) doSearch(searchInput.value);
  });
}

// Search button
const searchBtn = document.getElementById('search-btn');
if (searchBtn) {
  searchBtn.addEventListener('click', () => doSearch());
}

// Focus pills
document.querySelectorAll('.focus-pill').forEach((button) => {
  button.addEventListener('click', () => setView(button.dataset.view));
});

// Notification preferences form
const notifPrefForm = document.getElementById('notif-pref-form');
if (notifPrefForm) notifPrefForm.addEventListener('submit', saveNotificationPrefs);

// Mark all notifications as read
const markReadBtn = document.getElementById('mark-read-btn');
if (markReadBtn) markReadBtn.addEventListener('click', markAllNotificationsRead);

// Filter pills for profile
document.querySelectorAll('.filter-pill').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.filter-pill').forEach(p => p.classList.remove('active'));
    btn.classList.add('active');
  });
});

// Toast triggers
document.querySelectorAll('[data-toast]').forEach((button) => {
  button.addEventListener('click', () => showToast(button.dataset.toast || 'Done'));
});

// ========== SOCKET EVENT LISTENERS ==========

socket.on('state:update', (nextState) => {
  state = nextState;
  render();
});

socket.on('notification:new', (payload) => {
  showToast('🔔 ' + payload.text);
  // Re-fetch state to get updated notifications
  loadState();
});

socket.on('chat:message', (chat) => {
  // Update the chat in state
  const idx = state.chats.findIndex(c => c.id === chat.id);
  if (idx >= 0) {
    state.chats[idx] = chat;
  } else {
    state.chats.unshift(chat);
  }
  render();
});

socket.on('chat:typing', (data) => {
  const { chatId, userId, userName } = data;
  const indicator = document.getElementById('typing-indicator');
  if (!indicator) return;

  if (userId && chatId === activeChatId) {
    indicator.textContent = `${userName} is typing...`;
    indicator.style.display = 'block';
    clearTimeout(typingTimeouts[chatId]);
    typingTimeouts[chatId] = setTimeout(() => {
      indicator.style.display = 'none';
    }, 2000);
  } else {
    indicator.style.display = 'none';
  }
});

socket.on('users:online', (onlineIds) => {
  // Update friend statuses
  if (state) {
    state.social.friends.forEach(f => {
      f.status = onlineIds.includes(f.id) ? 'online' : 'offline';
    });
    render();
  }
});

// Chat typing indicator
const chatMessageInput = document.querySelector('#chat-message-form [name="chat-message"]');
if (chatMessageInput) {
  let typingTimer;
  chatMessageInput.addEventListener('input', () => {
    if (activeChatId) {
      socket.emit('chat:typing', { chatId: activeChatId, userId: state.user.id, userName: state.user.name });
      clearTimeout(typingTimer);
      typingTimer = setTimeout(() => {
        socket.emit('chat:typing:stop', { chatId: activeChatId, userId: state.user.id });
      }, 1000);
    }
  });
}

// ========== INIT ==========

if (document.getElementById('focus-preview')) {
  setView('feed');
}

setupFileUpload();

// If not on login page, emit online status
if (!window.location.pathname.includes('login') && !window.location.pathname === '/') {
  socket.emit('user:online', 'u1');
}

// Close search results on Escape
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') {
    const results = document.getElementById('search-results');
    if (results) results.style.display = 'none';
  }
});

loadState();

