const test = require('node:test');
const assert = require('node:assert/strict');
const { startServer, stopServer } = require('../server');

let server;
let baseUrl;

test.before(async () => {
  server = await startServer(0);
  baseUrl = `http://127.0.0.1:${server.address().port}`;
});

test.after(async () => {
  await stopServer();
});

test('register creates a user and returns a session token', async () => {
  const response = await fetch(`${baseUrl}/api/auth/register`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      name: 'Nova Lee',
      email: 'nova@example.com',
      password: 'secret123',
      role: 'Community Manager',
      location: 'Austin, USA',
      avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=300&q=80'
    })
  });

  assert.equal(response.status, 201);
  const data = await response.json();
  assert.ok(data.token);
  assert.equal(data.user.name, 'Nova Lee');
});

test('login page is served at the root and the app page is served at /app', async () => {
  const loginResponse = await fetch(`${baseUrl}/`);
  assert.equal(loginResponse.status, 200);
  const loginHtml = await loginResponse.text();
  assert.match(loginHtml, /Welcome back/);

  const appResponse = await fetch(`${baseUrl}/app`);
  assert.equal(appResponse.status, 200);
  const appHtml = await appResponse.text();
  assert.match(appHtml, /Create a post/);
});

test('login with valid credentials', async () => {
  const response = await fetch(`${baseUrl}/api/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email: 'ari@example.com', password: 'demo123' })
  });

  assert.equal(response.status, 200);
  const data = await response.json();
  assert.ok(data.token);
  assert.equal(data.user.name, 'Ari Chen');
});

test('login with invalid credentials returns 401', async () => {
  const response = await fetch(`${baseUrl}/api/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email: 'wrong@example.com', password: 'wrong' })
  });

  assert.equal(response.status, 401);
});

test('create a post', async () => {
  const response = await fetch(`${baseUrl}/api/posts`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      content: 'Test post with #hashtag',
      image: '',
      privacy: 'Public',
      tags: ['#hashtag']
    })
  });

  assert.equal(response.status, 200);
  const data = await response.json();
  assert.equal(data.author, 'Ari Chen');
  assert.ok(data.id);
  assert.ok(data.tags.includes('#hashtag'));
});

test('like and unlike a post', async () => {
  // Get state to find a post
  const stateRes = await fetch(`${baseUrl}/api/state`);
  const state = await stateRes.json();
  const postId = state.posts[0].id;

  // Like
  const likeRes = await fetch(`${baseUrl}/api/posts/${postId}/like`, { method: 'POST' });
  assert.equal(likeRes.status, 200);
  let post = await likeRes.json();
  assert.equal(post.likedByMe, true);

  // Unlike
  const unlikeRes = await fetch(`${baseUrl}/api/posts/${postId}/like`, { method: 'POST' });
  assert.equal(unlikeRes.status, 200);
  post = await unlikeRes.json();
  assert.equal(post.likedByMe, false);
});

test('comment on a post', async () => {
  const stateRes = await fetch(`${baseUrl}/api/state`);
  const state = await stateRes.json();
  const postId = state.posts[0].id;

  const response = await fetch(`${baseUrl}/api/posts/${postId}/comments`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ text: 'Great post!' })
  });

  assert.equal(response.status, 200);
});

test('send a friend request', async () => {
  const response = await fetch(`${baseUrl}/api/requests`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name: 'Test User', avatar: 'https://example.com/avatar.jpg' })
  });

  assert.equal(response.status, 200);
  const data = await response.json();
  assert.equal(data.status, 'pending');
});

test('search endpoint returns results', async () => {
  const response = await fetch(`${baseUrl}/api/search?q=design`);
  assert.equal(response.status, 200);
  const data = await response.json();
  assert.ok(Array.isArray(data.users));
  assert.ok(Array.isArray(data.posts));
  assert.ok(Array.isArray(data.hashtags));
});

test('update profile', async () => {
  const response = await fetch(`${baseUrl}/api/profile`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      name: 'Ari Chen Updated',
      role: 'Senior Product Designer',
      bio: 'Updated bio'
    })
  });

  assert.equal(response.status, 200);
  const data = await response.json();
  assert.equal(data.name, 'Ari Chen Updated');
  assert.equal(data.role, 'Senior Product Designer');
  assert.equal(data.headline, 'Updated bio');
});

test('update privacy settings', async () => {
  const response = await fetch(`${baseUrl}/api/privacy`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ posts: 'Public', messages: 'Friends', profile: 'Public' })
  });

  assert.equal(response.status, 200);
  const data = await response.json();
  assert.equal(data.posts, 'Public');
});

test('notification preferences', async () => {
  const response = await fetch(`${baseUrl}/api/notifications/preferences`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ likes: true, comments: false, messages: true })
  });

  assert.equal(response.status, 200);
  const data = await response.json();
  assert.equal(data.likes, true);
  assert.equal(data.comments, false);
});

test('mark all notifications as read', async () => {
  const response = await fetch(`${baseUrl}/api/notifications/read-all`, { method: 'POST' });
  assert.equal(response.status, 200);
});

test('send a chat message', async () => {
  const response = await fetch(`${baseUrl}/api/chats`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ participant: 'Mina Patel', text: 'Hello from test!' })
  });

  assert.equal(response.status, 200);
  const data = await response.json();
  assert.ok(data.messages.length > 0);
});

test('api state contains all required fields', async () => {
  const response = await fetch(`${baseUrl}/api/state`);
  assert.equal(response.status, 200);
  const state = await response.json();

  assert.ok(state.user);
  assert.ok(state.posts);
  assert.ok(state.requests);
  assert.ok(state.notifications);
  assert.ok(state.privacy);
  assert.ok(state.social);
  assert.ok(state.chats);
  assert.ok(state.trending);
  assert.ok(state.notificationPreferences);
  assert.ok(Array.isArray(state.posts));
  assert.ok(state.posts.length >= 6); // Should have rich dummy data
});

